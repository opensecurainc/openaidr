"""Replace only pinned scanner model attempts with the worker's typed bridge."""

import json
import os
from pathlib import Path
import re
import runpy

import httpx


def install():
    from pydantic import ValidationError
    from skillspector.llm_analyzer_base import LLMAnalyzerBase, _StructuredResponseValidationError

    projection = runpy.run_path(str(Path(__file__).with_name("skill_projection.py")))
    registry = projection["registry"]()
    task_for = projection["task_for"]
    origin, token = os.environ["OPENAIDR_SKILL_MODEL_ORIGIN"], os.environ["OPENAI_API_KEY"]
    if not re.fullmatch(r"http://127\.0\.0\.1:[1-9][0-9]{0,4}", origin):
        raise ValueError("Invalid scanner model bridge")

    def prepared(self, batch, **kwargs):
        return task_for(self, batch, kwargs)

    def finish(self, batch, value):
        expected = {"profile", "status", "request_hash", "billing", "result" if value.get("status") == "completed" else "code"}
        if set(value) != expected or value.get("profile") != "skill-assessment.1":
            raise RuntimeError("Invalid skill service response")
        if value.get("status") != "completed":
            code = value.get("code")
            if code == "invalid_response" and value["billing"]["state"] in ("disabled", "released"):
                raise _StructuredResponseValidationError()
            if code == "timeout":
                raise TimeoutError("Skill model deadline exceeded")
            if code == "provider_unavailable":
                raise ConnectionError("Skill model service unavailable")
            raise RuntimeError("Skill model task unavailable")
        try:
            result = self.response_schema.model_validate(value["result"])
        except (ValidationError, KeyError) as error:
            raise _StructuredResponseValidationError() from error
        return batch, self.parse_response(result, batch)

    def request(self, task):
        # The pinned loop may retry a known failed task. The tenant binds each
        # batch and blocks repeated dispatch when its previous outcome is unknown.
        self._uses_native_connection_retries = False
        remaining = self._require_time_remaining()
        timeout_ms = max(1, int(min(120, remaining if remaining is not None else 120) * 1000))
        return {"task": task, "timeout_ms": timeout_ms}, timeout_ms / 1000 + 5

    def read(response, chunks):
        # Tenant budget/pause/auth rejection must not trigger provider retry.
        if response.status_code in (502, 503):
            raise ConnectionError("Skill model service unavailable")
        if response.status_code != 200:
            raise RuntimeError("Tenant model admission unavailable")
        body = bytearray()
        for chunk in chunks:
            if len(body) + len(chunk) > 8 << 20:
                raise RuntimeError("Oversized model assessment")
            body.extend(chunk)
        return json.loads(body)

    def invoke(self, batch, task):
        body, timeout = request(self, task)
        with httpx.Client(trust_env=False, follow_redirects=False) as client:
            with client.stream("POST", origin + "/v1/skills/assess", json=body, timeout=timeout,
                               headers={"Authorization": "Bearer " + token}) as response:
                value = read(response, response.iter_bytes())
        return finish(self, batch, value)

    async def ainvoke(self, batch, task):
        body, timeout = request(self, task)
        async with httpx.AsyncClient(trust_env=False, follow_redirects=False) as client:
            async with client.stream("POST", origin + "/v1/skills/assess", json=body, timeout=timeout,
                                     headers={"Authorization": "Bearer " + token}) as response:
                chunks, size = [], 0
                async for chunk in response.aiter_bytes():
                    size += len(chunk)
                    if size > 8 << 20:
                        raise RuntimeError("Oversized model assessment")
                    chunks.append(chunk)
                value = read(response, chunks)
        return finish(self, batch, value)

    for cls in {LLMAnalyzerBase, *(entry[0] for entry in registry.values())}:
        cls.build_prompt = prepared
    LLMAnalyzerBase._invoke_batch = invoke
    LLMAnalyzerBase._ainvoke_batch = ainvoke
