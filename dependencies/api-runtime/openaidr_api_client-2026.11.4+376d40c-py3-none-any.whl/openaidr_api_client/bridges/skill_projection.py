"""Pinned scanner interface and task projection, loadable without either application.

Optional scanner imports remain inside functions so the SDK can ship this file
without installing the scanner runtime. Prompts come from the pinned scanner.
"""

from dataclasses import asdict


def registry():
    import skillspector
    from skillspector.llm_analyzer_base import LLMAnalyzerBase
    from skillspector.nodes.analyzers import semantic_developer_intent as intent
    from skillspector.nodes.analyzers import semantic_quality_policy as quality
    from skillspector.nodes.analyzers import semantic_security_discovery as discovery
    from skillspector.nodes.analyzers.mcp_tool_poisoning import _TP4Analyzer
    from skillspector.nodes.meta_analyzer import LLMMetaAnalyzer

    if skillspector.__version__ != "2.12.0":
        raise ValueError("Unsupported scanner interface")
    return {
        "semantic_security_discovery": (LLMAnalyzerBase, discovery.ANALYZER_PROMPT),
        "semantic_quality_policy": (LLMAnalyzerBase, quality.ANALYZER_PROMPT),
        "semantic_developer_intent": (LLMAnalyzerBase, intent.ANALYZER_PROMPT),
        "meta_analyzer": (LLMMetaAnalyzer, None),
        "mcp_tool_poisoning": (_TP4Analyzer, None),
    }


def task_for(analyzer, batch, kwargs):
    """Project accepted scanner input, without accepting a caller-supplied prompt."""
    from skillspector.nodes.analyzers.semantic_developer_intent import ANALYZER_PROMPT
    from skillspector.dependency_sources import redact_text

    name = analyzer._usage_collector._node
    metadata = ""
    projected = asdict(batch)
    # Only meta review includes static findings in the pinned model prompt.
    # Keep other finding evidence local, and apply its existing redaction
    # before the service hop, rather than only before the provider hop.
    projected["findings"] = []
    if name == "semantic_developer_intent":
        prefix, suffix = ANALYZER_PROMPT.split("{manifest_section}")
        if not analyzer.base_prompt.startswith(prefix) or not analyzer.base_prompt.endswith(suffix):
            raise ValueError("Unsupported developer intent prompt")
        metadata = analyzer.base_prompt[len(prefix):len(analyzer.base_prompt)-len(suffix) if suffix else None]
    elif name == "meta_analyzer":
        metadata = redact_text(str(kwargs.get("metadata_text", "No metadata available")))
        for finding in batch.findings:
            projected["findings"].append({
                **{key: getattr(finding, key) for key in ("rule_id", "finding_id", "severity", "file", "start_line", "end_line")},
                "message": redact_text(finding.message),
                "matched_text": redact_text(finding.matched_text or finding.message),
                "context": redact_text(finding.context or ""),
            })
    elif name != "mcp_tool_poisoning" and analyzer.base_prompt != registry()[name][1]:
        raise ValueError("Unsupported semantic prompt")
    return {"task": name, "batch": projected, "metadata": metadata}
