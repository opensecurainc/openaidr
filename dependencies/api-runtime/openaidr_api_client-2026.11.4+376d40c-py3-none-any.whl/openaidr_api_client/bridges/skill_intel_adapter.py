"""Run pinned SkillSpector with OSV lookups supplied by the worker's local bridge.

This file executes in the scanner's isolated Python environment. It must not
import the backend package or inherit the tenant's intelligence credential.
"""

import json
import os
import re

import httpx


def install():
    import skillspector
    from skillspector.inspection_ledger import LedgerReason
    from skillspector.nodes.analyzers import osv_client as osv, static_patterns_supply_chain as supply

    if (skillspector.__version__ != "2.12.0"
            or set(osv.VulnResult.__annotations__) != {"vuln_id", "summary", "severity", "aliases"}):
        raise RuntimeError("Unsupported intelligence adapter scanner interface")
    origin = os.environ["OPENAIDR_SKILL_INTEL_ORIGIN"]
    token = os.environ["OPENAIDR_SKILL_INTEL_TOKEN"]
    if not re.fullmatch(r"http://127\.0\.0\.1:[1-9][0-9]{0,4}", origin):
        raise ValueError("Invalid worker bridge")

    def query_batch(packages, ecosystem, *, timeout_seconds=None, budget=None):
        active = budget or osv.OsvQueryBudget.create(timeout_seconds)
        start, generation = len(active.limitations or []), active.limitation_generation
        retained = packages[:max(0, active.max_packages - active.packages_seen)]
        if len(retained) < len(packages):
            active.note(osv.OsvQueryLimitation(reason=LedgerReason.OUTPUT_LIMIT,
                        observed_records=active.packages_seen + len(packages), limit_records=active.max_packages))
        active.packages_seen += len(retained)
        results, queries, indices = [[] for _ in retained], [], []
        for index, pair in enumerate(retained):
            name, version = pair
            if (not isinstance(name, str) or not isinstance(version, str) or not version
                    or len(name) > osv.MAX_OSV_PACKAGE_NAME_CHARS
                    or len(version) > osv.MAX_OSV_PACKAGE_VERSION_CHARS):
                active.note(osv.OsvQueryLimitation(reason=LedgerReason.OPAQUE_CONTENT,
                            error_class="UnsupportedPackageCoordinate"))
                continue
            queries.append({"ecosystem": ecosystem, "name": name, "version": version})
            indices.append(index)
        successful, failed = False, False
        try:
            with httpx.Client(trust_env=False, follow_redirects=False,
                              headers={"Authorization": "Bearer " + token}) as client:
                for offset in range(0, len(queries), 25):
                    remaining = min(active.remaining_seconds(), 30)
                    if remaining <= 0:
                        active.note_runtime_limit()
                        break
                    if active.batches_sent >= active.max_batches:
                        active.note(osv.OsvQueryLimitation(reason=LedgerReason.OUTPUT_LIMIT,
                                    observed_records=active.batches_sent + 1, limit_records=active.max_batches))
                        break
                    active.batches_sent += 1
                    chunk = queries[offset:offset + 25]
                    body = bytearray()
                    with client.stream("POST", origin + "/v1/packages/check",
                                       json={"packages": chunk, "timeout": remaining}, timeout=remaining) as response:
                        response.raise_for_status()
                        for block in response.iter_bytes():
                            active.response_bytes += len(block)
                            if active.response_bytes > active.max_response_bytes:
                                active.note(osv.OsvQueryLimitation(reason=LedgerReason.SIZE_LIMIT,
                                            observed_bytes=active.response_bytes, limit_bytes=active.max_response_bytes))
                                raise ValueError("Response budget exceeded")
                            body.extend(block)
                    values = json.loads(body)["results"]
                    if not isinstance(values, list) or len(values) != len(chunk):
                        raise ValueError("Invalid bridge response")
                    successful = True
                    for index, value in zip(indices[offset:offset + 25], values, strict=True):
                        if value["status"] != "complete":
                            failed |= value["status"] == "unavailable"
                            active.note(osv.OsvQueryLimitation(
                                reason=LedgerReason.OPAQUE_CONTENT if value["status"] == "unsupported" else LedgerReason.ANALYZER_RUNTIME_ERROR,
                                error_class="UnsupportedPackageCoordinate" if value["status"] == "unsupported" else "IntelligenceUnavailable"))
                            continue
                        findings = value["findings"]
                        limit = min(osv.MAX_OSV_VULNS_PER_PACKAGE, max(0, active.max_results - active.results_retained))
                        if len(findings) > limit:
                            active.note(osv.OsvQueryLimitation(reason=LedgerReason.OUTPUT_LIMIT,
                                        observed_records=len(findings), limit_records=limit))
                        for finding in findings[:limit]:
                            severity = finding["severity"].upper()
                            if severity == "UNKNOWN":
                                severity = next((estimated for vector in finding["severity_vectors"]
                                                 if (estimated := osv._estimate_cvss_severity(vector["score"]))), None)
                                if severity is None:
                                    # Match the pinned scanner's conservative fallback;
                                    # the projection cannot prove complete severity coverage.
                                    severity = "HIGH"
                                    active.note(osv.OsvQueryLimitation(reason=LedgerReason.OPAQUE_CONTENT,
                                                error_class="IntelligenceSeverityUnavailable"))
                            results[index].append(osv.VulnResult(
                                vuln_id=finding["id"], summary=finding["summary"][:osv.MAX_OSV_SUMMARY_CHARS],
                                severity=severity, aliases=tuple(finding["aliases"][:osv.MAX_OSV_ALIASES])))
                            active.results_retained += 1
        except httpx.TimeoutException:
            active.note_runtime_limit()
            failed = True
        except (httpx.HTTPError, ValueError, TypeError, KeyError, RecursionError):
            active.note(osv.OsvQueryLimitation(reason=LedgerReason.ANALYZER_RUNTIME_ERROR,
                        error_class="IntelligenceUnavailable"))
            failed = True
        if queries:
            osv._last_query_ok = successful and not failed
        return osv.QueryBatchResults(results, limitations=osv._limitations_since(
            active, start_index=start, start_generation=generation))

    # Preserve the 256-package and 30-second aggregate budgets with 25-item API batches.
    osv.MAX_OSV_QUERIES_PER_BATCH = 25
    osv.MAX_OSV_QUERY_BATCHES = (osv.MAX_OSV_PACKAGES + 24) // 25
    osv.query_batch = supply.query_batch = query_batch


if __name__ == "__main__":
    if os.environ.get("OPENAIDR_SKILL_INTEL_ORIGIN"):
        install()
    if os.environ.get("OPENAIDR_SKILL_MODEL_ORIGIN"):
        from pathlib import Path
        import runpy

        runpy.run_path(str(Path(__file__).with_name("skill_model_adapter.py")))["install"]()
    from skillspector.cli import app

    app()
