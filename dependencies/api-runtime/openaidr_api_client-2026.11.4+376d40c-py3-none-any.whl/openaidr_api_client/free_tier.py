"""Bounded enrollment and tenant-bound free protection status helpers."""

import asyncio
import json
import re
import ssl
from uuid import UUID

import httpx

from .client import Unavailable
from .contracts.free_tier import FreeStatus, FreeUsageSnapshot
from .contracts.origin import browser_origin


def credential(installation_id, secret):
    """Construct the customer credential after enrollment confirms its tenant."""
    try:
        if not isinstance(secret, str) or not re.fullmatch(r"[A-Za-z0-9_-]{43}", secret):
            raise ValueError
        installation = UUID(installation_id).hex
    except (ValueError, TypeError, AttributeError):
        raise ValueError("Customer credential requires an installation UUID and enrollment secret") from None
    return "oasc_" + installation + "." + secret


def _status(value, tenant_id=None):
    try:
        result = FreeStatus.model_validate(value)
        if tenant_id is not None and result.tenant_id != tenant_id:
            raise ValueError("Free status tenant differs")
        return result
    except ValueError:
        raise Unavailable("Invalid free protection response") from None


async def status(client):
    value = await client.request("/v1/free/status", None, 4096, 10, method="GET")
    return _status(value, client.tenant_id)


def status_sync(client):
    value = client.request("/v1/free/status", None, 4096, 10, method="GET")
    return _status(value, client.tenant_id)


def usage_sync(client):
    value = client.request('/v1/free/usage', None, 4096, 5, method='GET')
    try:
        result = FreeUsageSnapshot.model_validate(value)
        if result.tenant_id != client.tenant_id:
            raise ValueError('Free usage tenant differs')
        return result
    except ValueError:
        raise Unavailable('Invalid free usage response') from None


async def enroll(origin, installation_id, device_id, secret, *, ca_file="", transport=None):
    """Submit an installation secret to one exact HTTPS origin, without redirects.

    Persist the caller-generated installation identifiers and secret before this
    request. Repeating the same enrollment recovers the same tenant. Construct
    the credential locally; responses contain no credential or provider costs.
    """
    try:
        if (browser_origin(origin) != origin or not origin.startswith("https://")
                or not isinstance(secret, str) or not re.fullmatch(r"[A-Za-z0-9_-]{43}", secret)):
            raise ValueError
        payload = dict(installation_id=str(UUID(installation_id)), device_id=str(UUID(device_id)), secret=secret)
        verify = ssl.create_default_context(cafile=ca_file) if ca_file else True
    except (ValueError, TypeError, AttributeError, OSError):
        raise ValueError("Free enrollment requires an exact HTTPS origin, installation UUID, device UUID, secret and valid trust bundle") from None
    try:
        async with asyncio.timeout(10):
            async with httpx.AsyncClient(base_url=origin, transport=transport, verify=verify,
                                         trust_env=False, follow_redirects=False, timeout=10,
                                         headers={"Accept-Encoding": "identity"}) as client:
                async with client.stream("POST", "/v1/free/enroll", json=payload) as response:
                    if response.status_code != 200:
                        raise Unavailable("Free enrollment unavailable", status_code=response.status_code,
                                          retry_after=response.headers.get("retry-after"))
                    if response.headers.get("content-encoding", "identity") != "identity":
                        raise Unavailable("Invalid free enrollment response")
                    body = bytearray()
                    async for chunk in response.aiter_bytes():
                        body.extend(chunk)
                        if len(body) > 4096:
                            raise Unavailable("Free enrollment response exceeds limit")
        return _status(json.loads(body))
    except (httpx.HTTPError, TimeoutError):
        raise Unavailable("Free enrollment unavailable") from None
    except (ValueError, RecursionError):
        raise Unavailable("Invalid free enrollment response") from None
