"""Shared osv limits and validation."""

import re
from datetime import timedelta


REFRESH = timedelta(days=1)


BATCH = 25


MAX_ADVISORIES = 256


MAX_RESPONSE = 4 * 1024 * 1024


MAX_QUERY_PAGES = 10


MAX_NAME = 214


MAX_VERSION = 256


MAX_SUMMARY = 2048


MAX_VECTORS = 8


MAX_VECTOR_SCORE = 512


NPM_NAME = r"(?:@[a-z0-9][a-z0-9._-]*/)?[a-z0-9][a-z0-9._-]*"


_NUMBER = r"(?:0|[1-9][0-9]*)"


_PRERELEASE = rf"(?:{_NUMBER}|[0-9]*[A-Za-z-][0-9A-Za-z-]*)"


NPM_VERSION = (rf"v?{_NUMBER}\.{_NUMBER}\.{_NUMBER}(?:-{_PRERELEASE}(?:\.{_PRERELEASE})*)?"
               r"(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?")


PYPI_NAME = r"[A-Za-z0-9](?:[A-Za-z0-9._-]*[A-Za-z0-9])?"


PYPI_VERSION = (r"(?:[0-9]+!)?[0-9]+(?:\.[0-9]+)*(?:(?:a|b|rc)[0-9]+)?"
                r"(?:\.post[0-9]+)?(?:\.dev[0-9]+)?(?:\+[a-z0-9]+(?:[._-][a-z0-9]+)*)?")


ID = re.compile(r"[A-Za-z0-9:_.-]{1,200}\Z")


KEY_FIELDS = ("ecosystem", "identifier", "version")


def package_query(row):
    """Accept registry package identities only, never paths or inferred MCP names."""
    ecosystem, name, version = (row.get(field, "") for field in KEY_FIELDS)
    if row.get("kind", "package") != "package" or ecosystem not in ("npm", "pypi"):
        return None, "Package identity not reported"
    if not version:
        return None, "Version not reported"
    if len(name) > MAX_NAME or len(version) > MAX_VERSION:
        return None, "Package identity or version is unsupported"
    if ecosystem == "npm":
        valid_name = re.fullmatch(NPM_NAME, name)
        valid_version = re.fullmatch(NPM_VERSION, version)
    else:
        valid_name = re.fullmatch(PYPI_NAME, name)
        # Accept canonical PEP 440 releases. Unrecognized spellings remain
        # unassessed instead of using OSV's fuzzy matching as validation.
        valid_version = re.fullmatch(PYPI_VERSION, version, re.IGNORECASE)
        name = re.sub(r"[-_.]+", "-", name).lower()
    if not valid_name or not valid_version:
        return None, "Package identity or version is unsupported"
    return {"package": {"ecosystem": "npm" if ecosystem == "npm" else "PyPI", "name": name}, "version": version}, ""


class Unavailable(Exception):
    """External failures are reported without provider response bodies or inventory."""
