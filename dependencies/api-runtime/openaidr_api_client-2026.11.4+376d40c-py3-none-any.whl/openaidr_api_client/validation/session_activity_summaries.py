"""Shared session activity summaries limits and validation."""

import json
from openaidr_common.redact import redact_value


MAX_RECORDS = 40


MAX_INPUT_CHARS = 16000


def validate_answer(answer):
    result = json.loads(answer)
    if not isinstance(result, dict) or set(result) != {"summary"}:
        raise ValueError("invalid session summary")
    text = result["summary"]
    if text is not None:
        if not isinstance(text, str) or not text.strip() or len(text) > 240:
            raise ValueError("invalid session summary text")
        text = redact_value(" ".join(text.split()))
        if len(text) > 240:
            raise ValueError("redacted session summary is too long")
    return {"summary": text}
