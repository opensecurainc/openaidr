"""Shared page chat limits and validation."""

import json
from contextlib import contextmanager

import httpx
from openaidr_api_client.client import Unavailable
from openaidr_api_client.contracts.errors import APIError, require




MAX_PAGE_CHARS = 20_000


MAX_HISTORY_CHARS = 24_000


def validate_input(data):
    require(set(data) == {"page", "messages"}, "provide page and messages only")
    page = data["page"]
    require(isinstance(page, dict), "page must be an object")
    require(
        set(page) == {"path", "title", "text", "truncated"},
        "page must contain path, title, text, and truncated",
    )
    for key, limit in (("path", 2048), ("title", 200), ("text", MAX_PAGE_CHARS)):
        value = page[key]
        require(
            isinstance(value, str) and value.strip() and len(value) <= limit,
            f"page {key} must contain 1 to {limit} characters",
        )
    require(
        page["path"].startswith("/") and not page["path"].startswith("//"),
        "page path must be a local path",
    )
    require(type(page["truncated"]) is bool, "truncated must be a boolean")
    messages = data["messages"]
    require(
        isinstance(messages, list)
        and 1 <= len(messages) <= 9
        and len(messages) % 2 == 1,
        "provide up to four prior turns and a question",
    )
    for index, message in enumerate(messages):
        require(isinstance(message, dict), "message must be an object")
        require(set(message) == {"role", "content"}, "provide role and content only")
        role = "user" if index % 2 == 0 else "assistant"
        require(message["role"] == role, f"expected {role} message")
        content = message["content"]
        limit = 4000 if role == "user" else 8000
        require(
            isinstance(content, str) and content.strip() and len(content) <= limit,
            f"message must contain 1 to {limit} characters",
        )
    require(
        sum(len(message["content"]) for message in messages) <= MAX_HISTORY_CHARS,
        "conversation is too long; start a new chat",
    )
    try:
        json.dumps(data, ensure_ascii=False).encode("utf-8")
    except UnicodeEncodeError:
        raise APIError(400, "page and messages must contain valid Unicode") from None


async def sse_events(response):
    """Bound every byte, including comments and unterminated lines, before parsing."""
    pending, lines = bytearray(), []
    total = event_size = 0
    async for chunk in response.aiter_bytes():
        total += len(chunk)
        if total > 4 << 20:
            raise ValueError("oversized stream")
        pending.extend(chunk)
        while b"\n" in pending:
            line, _, rest = pending.partition(b"\n")
            pending = bytearray(rest)
            event_size += len(line) + 1
            if event_size > 1 << 20:
                raise ValueError("oversized stream event")
            line = line.rstrip(b"\r")
            if line:
                if line.startswith(b"data:"):
                    lines.append(line[5:].lstrip(b" "))
            else:
                if lines:
                    yield json.loads(b"\n".join(lines))
                lines, event_size = [], 0
        if event_size + len(pending) > 1 << 20:
            raise ValueError("oversized stream event")


@contextmanager
def provider_errors():
    try:
        yield
    except (httpx.TimeoutException, TimeoutError):
        raise APIError(
            504, "OpenAIDR Assistant took too long. Please try again."
        ) from None
    except (httpx.HTTPError, Unavailable):
        raise APIError(
            502, "Cannot reach OpenAIDR Assistant. Please try again."
        ) from None
    except (ValueError, KeyError, TypeError, AttributeError, RecursionError):
        raise APIError(
            502, "OpenAIDR Assistant returned an incomplete answer. Please try again."
        ) from None
