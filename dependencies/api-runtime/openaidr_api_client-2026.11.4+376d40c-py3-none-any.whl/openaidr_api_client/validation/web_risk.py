"""Shared web risk limits and validation."""

import ipaddress
import json
import re
import time
from datetime import datetime
from urllib.parse import parse_qsl, unquote, urlsplit, urlunsplit

import httpx
from openaidr_common.redact import is_secret_key, redact_string


THREAT_TYPES = ("MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE")


MAX_URLS = 16


MAX_URL_BYTES = 4096


# Matching URLs also travel in the hook reply, whose installed-client cap is 64 KiB.
MAX_URL_TOTAL_BYTES = 24 << 10


MAX_RESPONSE_BYTES = 8192


LOOKUP_TIMEOUT = 1.0


CACHE_SIZE = 1024


URL = re.compile(r"https?://[^\s<>\"'`]+", re.I)


PRIVATE_SUFFIXES = (".localhost", ".local", ".internal", ".lan", ".home", ".home.arpa", ".onion", ".test", ".invalid")


def _texts(value):
    if isinstance(value, str):
        if value.lstrip().startswith(("{", "[")):
            try:
                yield from _texts(json.loads(value))
                return
            except (ValueError, RecursionError):
                pass
        yield value
    elif isinstance(value, dict):
        for key, item in value.items():
            if not is_secret_key(key):
                yield from _texts(item)
    elif isinstance(value, list):
        for item in value:
            yield from _texts(item)


def _public_url(value):
    """Do not send private destinations or recognizable credentials to Google."""
    if len(value.encode()) > MAX_URL_BYTES:
        return None
    decoded = unquote(value)
    if ("[redacted" in decoded.lower() or redact_string(decoded)[1]
            or any(ord(char) < 32 for char in decoded) or "\\" in decoded):
        return None
    try:
        parts = urlsplit(value)
        host = httpx.URL(value).raw_host.decode("ascii").lower().rstrip(".")
        if (parts.scheme.lower() not in ("http", "https") or parts.username is not None
                or not host or parts.port == 0 or "%" in host):
            return None
        try:
            if not ipaddress.ip_address(host).is_global:
                return None
        except ValueError:
            if ("." not in host or any(host == suffix[1:] or host.endswith(suffix) for suffix in PRIVATE_SUFFIXES)
                    or host.rsplit(".", 1)[-1].isdigit()
                    or not re.fullmatch(r"[a-z0-9.-]+", host)
                    or any(not label or label.startswith("-") or label.endswith("-")
                           for label in host.split("."))):
                return None
        if any(is_secret_key(key) or re.search(r"(?:^|[-_])(?:key|sig|signature|auth|code)(?:$|[-_])", key, re.I)
               for key, _ in parse_qsl(parts.query, keep_blank_values=True)):
            return None
        # A fragment is not sent when fetching a URL and can hold credentials.
        netloc = f"[{host}]" if ":" in host else host
        if parts.port is not None:
            netloc += f":{parts.port}"
        return urlunsplit((parts.scheme.lower(), netloc, parts.path or "/", parts.query, ""))
    except (ValueError, UnicodeError, httpx.InvalidURL):
        return None


def extract_urls(actions):
    urls, seen, skipped, total_bytes = [], set(), 0, 0
    for action in actions:
        tool, command, network = (action.get(key) or {} for key in ("tool", "command", "network"))
        values = (action.get("text"), tool.get("input"), tool.get("output"),
                  command.get("text"), network.get("url"))
        for value in values:
            for text in _texts(value):
                for match in URL.finditer(text):
                    candidate = match.group().rstrip(".,;!?")
                    for left, right in (("(", ")"), ("[", "]"), ("{", "}")):
                        while candidate.endswith(right) and candidate.count(right) > candidate.count(left):
                            candidate = candidate[:-1]
                    if candidate in seen:
                        continue
                    seen.add(candidate)
                    url = _public_url(candidate)
                    if url in urls:
                        continue
                    if (url is None or len(urls) >= MAX_URLS
                            or total_bytes + len(url.encode()) > MAX_URL_TOTAL_BYTES):
                        skipped += 1
                    else:
                        urls.append(url)
                        total_bytes += len(url.encode())
    return urls, skipped


def _expiry(value):
    if not isinstance(value, str):
        raise ValueError("invalid expiry")
    expiry = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if expiry.tzinfo is None or expiry.timestamp() <= time.time():
        raise ValueError("expired result")
    return expiry
