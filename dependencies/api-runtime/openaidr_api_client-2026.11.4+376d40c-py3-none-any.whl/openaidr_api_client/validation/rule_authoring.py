"""Shared rule authoring limits and validation."""

import copy
from pathlib import PurePosixPath, PureWindowsPath
from openaidr_common.event import PRODUCTS
from openaidr_common.policy import compile_rules
from openaidr_api_client.contracts.errors import APIError, require


KINDS = ("command", "file.read", "file.write", "network", "tool.call")


ACTIONS = ("deny", "ask", "warn")


MATCH_FIELDS = ("kinds", "products", "tool_name", "command_regex", "path_glob", "host_glob")


EXAMPLE_FIELDS = ("label", "kind", "value", "product", "tool_name", "os", "path_home", "expected_match")


def object_schema(properties):
    return {"type": "object", "properties": properties,
            "required": list(properties), "additionalProperties": False}


TEXT = {"type": "string"}


RULE_SCHEMA = object_schema({
    "name": TEXT, "action": {"type": "string", "enum": list(ACTIONS)}, "reason": TEXT,
    "match": object_schema({
        "kinds": {"type": "array", "items": {"type": "string", "enum": list(KINDS)}},
        "products": {"type": "array", "items": {"type": "string", "enum": list(PRODUCTS)}},
        **{key: TEXT for key in MATCH_FIELDS[2:]},
    }),
})


EXAMPLE_SCHEMA = object_schema({
    "label": TEXT, "kind": {"type": "string", "enum": list(KINDS)}, "value": TEXT,
    "product": {"type": "string", "enum": ["", *PRODUCTS]}, "tool_name": TEXT,
    "os": {"type": "string", "enum": ["linux", "darwin", "windows"]},
    "path_home": TEXT, "expected_match": {"type": "boolean"},
})


def text(value, label, limit, *, empty=False):
    require(isinstance(value, str) and len(value) <= limit
            and (empty or value.strip()) and "\x00" not in value,
            f"{label} must contain {'0' if empty else '1'} to {limit} characters")
    try:
        value.encode("utf-8")
    except UnicodeError:
        raise APIError(400, f"{label} must be valid UTF-8 text") from None
    return value


def validate_draft(draft):
    require(isinstance(draft, dict) and set(draft) == {
        "intent", "explanation", "limitations", "rule", "examples"}, "invalid rule draft")
    text(draft["intent"], "Description", 4000)
    text(draft["explanation"], "Explanation", 1000)
    require(isinstance(draft["limitations"], list) and len(draft["limitations"]) <= 5,
            "provide up to 5 limitations")
    for value in draft["limitations"]:
        text(value, "Limitation", 300)
    rule = draft["rule"]
    require(isinstance(rule, dict) and set(rule) == {"name", "action", "reason", "match"},
            "invalid draft rule fields")
    text(rule["name"], "Rule name", 120)
    text(rule["reason"], "Rule reason", 500)
    require(rule["action"] in ACTIONS, "draft action must be deny, ask, or warn")
    match = rule["match"]
    require(isinstance(match, dict) and set(match) == set(MATCH_FIELDS), "unsupported match fields")
    for key, allowed in (("kinds", KINDS), ("products", PRODUCTS)):
        values = match[key]
        require(isinstance(values, list) and len(values) <= len(allowed)
                and all(isinstance(value, str) and value in allowed for value in values),
                f"unsupported {key}")
    require(bool(match["kinds"]), "choose at least one event kind")
    for key in MATCH_FIELDS[2:]:
        text(match[key], key, 2000 if key == "command_regex" else 500, empty=True)
    require("*" not in match["tool_name"].rstrip("*")
            and "**" not in match["tool_name"], "tool name supports only one trailing *")
    try:
        _, errors = compile_rules({"rules": [{**rule, "enabled": True}]})
    except (RecursionError, OverflowError):
        raise APIError(400, "A match condition exceeds the supported complexity.") from None
    require(not errors, "A match condition is invalid. Check the regex and globs.")
    examples = draft["examples"]
    require(isinstance(examples, list) and 2 <= len(examples) <= 8, "provide 2 to 8 test cases")
    for example in examples:
        require(isinstance(example, dict) and set(example) == set(EXAMPLE_FIELDS), "invalid test case fields")
        text(example["label"], "Test label", 120)
        text(example["value"], "Test input", 2000)
        text(example["tool_name"], "Test tool", 200, empty=True)
        text(example["path_home"], "Test home directory", 500, empty=True)
        home = example["path_home"]
        require(not home or PurePosixPath(home).is_absolute() or PureWindowsPath(home).is_absolute(),
                "test home directory must be absolute")
        if match["path_glob"].replace("\\", "/").startswith("~/") or match["path_glob"] == "~":
            require(bool(home), "provide the endpoint home directory for home-relative path tests")
        require(example["kind"] in KINDS and example["product"] in ("", *PRODUCTS)
                and example["os"] in ("linux", "darwin", "windows")
                and type(example["expected_match"]) is bool, "invalid test case context")
    require({example["expected_match"] for example in examples} == {True, False},
            "include a matching and a non-matching test case")
    return copy.deepcopy(draft)


def validate_result(intent, result):
    try:
        require(isinstance(result, dict), "invalid generated draft")
        if result.get("status") == "draft":
            require(set(result) == {"status", "draft"}, "invalid generated draft")
            draft = validate_draft(result["draft"])
            require(draft["intent"] == intent, "draft does not match submitted intent")
            return {"status": "draft", "draft": draft}
        require(set(result) == {"status", "explanation"} and result["status"] in ("clarify", "unsupported"),
                "invalid clarification")
        text(result["explanation"], "Explanation", 1000)
        return result
    except APIError:
        raise ValueError("invalid generated draft") from None
