"""Shared request and result validation without provider execution."""
