"""Shared application assessment limits and validation."""


DIMENSIONS = ("code_execution", "file_access", "external_transmission", "autonomy")


FACT = {
    "type": "object", "additionalProperties": False,
    "required": ["reason", "sources"],
    "properties": {
        "reason": {"type": "string"},
        "sources": {"type": "array", "items": {"type": "string"}},
    },
}


REPORT = {
    "type": "object", "additionalProperties": False,
    "required": ["purpose", "harms"],
    "properties": {
        "purpose": {**FACT, "properties": {
            **FACT["properties"], "reason": {"type": "string", "minLength": 1, "maxLength": 240},
            "sources": {"type": "array", "maxItems": 5, "items": {"type": "string"}},
        }},
        "harms": {"type": "array", "maxItems": 3, "items": {
            "type": "object", "additionalProperties": False,
            "required": ["damage", "likelihood", "sources"],
            "properties": {
                "damage": {"type": "string", "minLength": 1, "maxLength": 180},
                "likelihood": {"type": "string", "minLength": 1, "maxLength": 240},
                "sources": {"type": "array", "minItems": 1, "maxItems": 5, "items": {"type": "string"}},
            },
        }},
    },
}


SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["confidence", "summary", *DIMENSIONS, "controls", "reputation", "risk", "report"],
    "properties": {
        "report": REPORT,
        "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
        "summary": {"type": "string"},
        **{key: {**FACT, "required": ["level", *FACT["required"]], "properties": {
            **FACT["properties"], "level": {"type": ["integer", "null"], "enum": [0, 1, 2, 3, None]},
        }} for key in DIMENSIONS},
        "controls": FACT,
        "reputation": FACT,
        "risk": {**FACT, "required": ["score", *FACT["required"]], "properties": {
            **FACT["properties"], "score": {"type": ["integer", "null"], "minimum": 0, "maximum": 100},
        }},
    },
}


def parse(value, urls, *, identified, ai_application, score_eligible):
    if (not isinstance(value, dict) or set(value) != set(SCHEMA["required"])
            or value["confidence"] not in ("high", "medium", "low")
            or not isinstance(value["summary"], str) or not 1 <= len(value["summary"].strip()) <= 1000):
        raise ValueError("unsupported capability assessment")
    report = value["report"]
    if not isinstance(report, dict) or set(report) != {"purpose", "harms"}:
        raise ValueError("unsupported application report")
    purpose, harms = report["purpose"], report["harms"]
    if (not isinstance(purpose, dict) or set(purpose) != {"reason", "sources"}
            or not isinstance(purpose["reason"], str) or not purpose["reason"].strip() or len(purpose["reason"]) > 240
            or not isinstance(purpose["sources"], list) or len(purpose["sources"]) > 5
            or any(not isinstance(url, str) or url not in urls for url in purpose["sources"])
            or not isinstance(harms, list) or len(harms) > 3):
        raise ValueError("unsupported application report")
    for harm in harms:
        if (not isinstance(harm, dict) or set(harm) != {"damage", "likelihood", "sources"}
                or any(not isinstance(harm[key], str) or not harm[key].strip() or len(harm[key]) > limit
                       for key, limit in (("damage", 180), ("likelihood", 240)))
                or not isinstance(harm["sources"], list) or not 1 <= len(harm["sources"]) <= 5
                or any(not isinstance(url, str) or url not in urls for url in harm["sources"])):
            raise ValueError("unsupported application report evidence")
    for key in (*DIMENSIONS, "controls", "reputation", "risk"):
        fact = value[key]
        required = {"reason", "sources"} | ({"level"} if key in DIMENSIONS else {"score"} if key == "risk" else set())
        if (not isinstance(fact, dict) or set(fact) != required
                or not isinstance(fact["reason"], str) or not 1 <= len(fact["reason"].strip()) <= 1000
                or not isinstance(fact["sources"], list) or len(fact["sources"]) > 5
                or any(not isinstance(url, str) or url not in urls for url in fact["sources"])):
            raise ValueError("unsupported capability evidence")
        if key in DIMENSIONS and fact["level"] is not None:
            if type(fact["level"]) is not int or not 0 <= fact["level"] <= 3 or not fact["sources"]:
                raise ValueError("unsupported capability level")
    risk = value["risk"]
    if (risk["score"] is None and score_eligible) or (risk["score"] is not None and (
            type(risk["score"]) is not int or not 0 <= risk["score"] <= 100)):
        raise ValueError("unsupported risk assessment")
    levels = [value[key]["level"] for key in DIMENSIONS]
    risk_supported = (identified and ai_application and value["confidence"] != "low"
                      and any(level is not None for level in levels) and bool(risk["sources"]))
    provisional = score_eligible and not risk_supported
    confidence = ("low" if score_eligible and (not identified or not any(level is not None for level in levels))
                  else value["confidence"])
    supported = identified and confidence != "low" and all(level is not None for level in levels)
    # Four equally weighted dimensions, rounded half up. Available controls do
    # not discount capability: their enabled state is not observed by inventory.
    # Keep the old score contract so older dashboards can read provisional results.
    return {**value, "confidence": confidence,
            "capability_score": (sum(levels) * 100 + 6) // 12 if supported else None,
            "risk": {**risk, "score": risk["score"] if risk_supported else None,
                     "provisional_score": risk["score"] if provisional else None}}
