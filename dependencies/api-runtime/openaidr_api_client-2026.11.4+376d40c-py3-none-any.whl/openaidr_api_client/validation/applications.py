"""Shared applications limits and validation."""

from copy import deepcopy
import math
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from urllib.parse import urlsplit
from openaidr_api_client.validation import application_assessment




SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["needs_attention", "category", "reason", "sources", "software_type", "display_name", "assessment"],
    "properties": {
        "assessment": application_assessment.SCHEMA,
        "needs_attention": {"type": ["boolean", "null"]},
        "category": {"type": ["string", "null"], "enum": [
            "coding_agent", "chat_assistant", "local_model_runtime", "other_ai", "ordinary", None,
        ]},
        "reason": {"type": "string"},
        "sources": {"type": "array", "items": {"type": "string"}},
        "software_type": {"type": ["string", "null"], "enum": [
            "application", "command_line_tool", "library", "helper", "system_component", None,
        ]},
        "display_name": {"type": ["string", "null"]},
    },
}


def _url(value):
    if not isinstance(value, str) or len(value) > 2048:
        return False
    try:
        url = urlsplit(value)
        return (url.scheme in ("https", "http") and bool(url.hostname)
                and not url.username and not url.password
                and not any(ord(char) < 33 for char in value))
    except ValueError:
        return False


def parse_classification(result, urls):
    """Apply the same semantic and citation checks to provider and service results."""
    if (not isinstance(result, dict)
            or set(result) != set(SCHEMA["required"])
            or (result["needs_attention"] is not None and type(result["needs_attention"]) is not bool)
            or result["category"] not in SCHEMA["properties"]["category"]["enum"]
            or result["software_type"] not in SCHEMA["properties"]["software_type"]["enum"]
            or (result["display_name"] is not None and (
                not isinstance(result["display_name"], str)
                or not 1 <= len(result["display_name"].strip()) <= 120
                or any(ord(char) < 32 for char in result["display_name"])))
            or (result["category"] == "coding_agent" and result["software_type"] in (
                "library", "helper", "system_component"))
            or (result["needs_attention"] is None and result["category"] is not None)
            or (result["needs_attention"] is False and result["category"] != "ordinary")
            or (result["needs_attention"] is True and result["category"] not in (
                "coding_agent", "chat_assistant", "local_model_runtime", "other_ai"))
            or not isinstance(result["reason"], str) or not 1 <= len(result["reason"].strip()) <= 1000
            or not isinstance(result["sources"], list) or len(result["sources"]) > 5
            or any(not _url(url) or url not in urls for url in result["sources"])
            or (any(result[key] is not None for key in (
                "needs_attention", "software_type", "display_name")) and not result["sources"])):
        raise ValueError("unsupported classification")
    result["assessment"] = application_assessment.parse(
        result["assessment"], urls,
        identified=result["needs_attention"] is not None and result["software_type"] is not None,
        ai_application=result["needs_attention"] is True and result["software_type"] in ("application", "command_line_tool"),
        score_eligible=result["needs_attention"] is not False and result["software_type"] in (None, "application", "command_line_tool"),
    )
    return result


def cited_urls(value):
    """Only cited research URLs cross the service boundary."""
    urls = set()
    if isinstance(value, dict):
        for key, item in value.items():
            if key == "sources":
                urls.update(item)
            else:
                urls.update(cited_urls(item))
    elif isinstance(value, list):
        for item in value:
            urls.update(cited_urls(item))
    return sorted(urls)


def retry_delay(value):
    try:
        delay = float(value)
    except (TypeError, ValueError):
        try:
            delay = (parsedate_to_datetime(value) - datetime.now(timezone.utc)).total_seconds()
        except (TypeError, ValueError, OverflowError):
            delay = 60
    return max(60, delay) if math.isfinite(delay) else 60
