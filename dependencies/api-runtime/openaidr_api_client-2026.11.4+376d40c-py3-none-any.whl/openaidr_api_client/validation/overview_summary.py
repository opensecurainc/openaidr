"""Shared overview summary limits and validation."""

import json
import re


MAX_SOURCES = 24


TOPICS = ("Detection", "Findings", "Coverage", "Guardrail", "Assets", "Costs")


TONES = ("critical", "high", "warning", "info", "positive", "neutral")


ITEM_FIELDS = {"topic", "headline", "caption", "text", "detail", "tone", "citations"}


COST_WINDOW = re.compile(r"24[ -]?h(?:ours?)?\b", re.IGNORECASE)


def validate_answer(answer, sources):
    result = json.loads(answer)
    if not isinstance(result, dict) or set(result) != {"items"}:
        raise ValueError("invalid summary")
    items = result["items"]
    if not isinstance(items, list) or not 1 <= len(items) <= 6:
        raise ValueError("invalid summary items")
    ids = {source["id"] for source in sources}
    priced = {source["id"] for source in sources
              if source["status"] == "available" and source["path"].startswith("/costs/")}
    topics = set()
    for item in items:
        if not isinstance(item, dict) or set(item) != ITEM_FIELDS:
            raise ValueError("invalid summary item")
        if item["topic"] not in TOPICS or item["topic"] in topics or item["tone"] not in TONES:
            raise ValueError("invalid topic or tone")
        topics.add(item["topic"])
        for field, limit in (("headline", 16), ("text", 150), ("detail", 900)):
            if not isinstance(item[field], str) or not item[field].strip() or len(item[field]) > limit:
                raise ValueError("invalid summary text")
        if not isinstance(item["caption"], str) or len(item["caption"]) > 40:
            raise ValueError("invalid summary caption")
        # A cost figure without its window reads as a daily or monthly total.
        # An unavailable cost source has no figure, so its item needs no window.
        if item["topic"] == "Costs" and any(ref in priced for ref in item["citations"]) \
                and not COST_WINDOW.search(item["text"]):
            raise ValueError("cost summary omits its time window")
        refs = item["citations"]
        if not isinstance(refs, list) or not 1 <= len(refs) <= 4 or any(not isinstance(ref, str) or ref not in ids for ref in refs):
            raise ValueError("invalid source reference")
    return result
