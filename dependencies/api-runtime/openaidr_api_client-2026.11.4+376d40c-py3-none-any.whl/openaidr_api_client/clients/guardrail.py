"""Advisory service assessments using the same bounded transport as threat intel."""

from datetime import datetime
import math

import httpx
from pydantic import ValidationError

from openaidr_api_client.client import IntelligenceClient, Unavailable
from openaidr_api_client.latency import measured
from openaidr_api_client.contracts.credits import BillingReceipt, microcredits
from openaidr_api_client.contracts.injection import InjectionAssessment, InjectionState
from openaidr_api_client.contracts.service_guardrail import (
    ServiceGuardrailAssessment, GuardrailError, MAX_RESPONSE_BYTES, REQUEST_TIMEOUT,
)


def result(payload, request_id, *, injection=False):
    # Valid accounting remains usable even when the advisory result is invalid.
    billing = None
    try:
        parsed = BillingReceipt.model_validate(payload.get("billing")).model_dump()
        if parsed["request_id"] == request_id and parsed["service"] == "guardrail":
            billing = parsed
    except (ValidationError, AttributeError):
        pass
    try:
        value = (InjectionAssessment if injection else ServiceGuardrailAssessment).model_validate(payload).model_dump()
        if billing is None:
            raise ValueError
        if value["status"] == "error":
            error = GuardrailError(value["reason"], retryable=value["retryable"], retry_after=value["retry_after"])
            error.billing = billing
            raise error
        if billing["state"] not in ("disabled", "settled"):
            raise ValueError
        assessed = datetime.fromisoformat(value["assessed_at"].replace("Z", "+00:00"))
        if assessed.tzinfo is None:
            raise ValueError
        if value["status"] == "scored" and not injection:
            score, category = value["score"], value["category"]
            level = ("info", "low", "medium", "high", "critical")[min(4, int(score // 20))]
            if (value["level"] != level or (category == "none" and score >= 40)
                    or (category != "none" and score == 0)):
                raise ValueError
        return value
    except (ValidationError, ValueError, TypeError, KeyError, AttributeError):
        error = GuardrailError("invalid_response")
        error.billing = billing
        raise error from None


def request(state, company_policy, timeout):
    seconds = REQUEST_TIMEOUT if timeout is None else min(REQUEST_TIMEOUT, timeout)
    if not math.isfinite(seconds) or seconds < .001:
        raise GuardrailError("connection_failed", retryable=True)
    return {"state": state, "company_policy": company_policy,
            "timeout_ms": int(seconds * 1000)}, seconds


def injection_request(state, timeout):
    payload, seconds = request(InjectionState.model_validate(state).model_dump(), "", timeout)
    payload.pop("company_policy")
    return payload, seconds


class AsyncGuardrailClient:
    def __init__(self, connection, *, transport=None):
        self.client = IntelligenceClient.from_connection(connection, transport=transport)

    @measured("guardrail")
    async def assess(self, state, *, request_id, company_policy="", timeout=None, max_credits=None):
        payload, seconds = request(state, company_policy, timeout)
        if max_credits is not None:
            microcredits(max_credits)
            payload["max_credits"] = max_credits
        try:
            response = await self.client.request("/v1/services/guardrail/assess", payload, MAX_RESPONSE_BYTES, seconds, request_id=request_id)
        except (httpx.RequestError, TimeoutError):
            raise GuardrailError("connection_failed", retryable=True) from None
        except Unavailable:
            raise GuardrailError("provider_unavailable", retryable=True) from None
        return result(response, request_id)

    @measured("guardrail")
    async def assess_injection(self, state, *, request_id, timeout=None):
        payload, seconds = injection_request(state, timeout)
        try:
            response = await self.client.request("/v1/services/guardrail/injection", payload,
                                                 MAX_RESPONSE_BYTES, seconds, request_id=request_id)
        except (httpx.RequestError, TimeoutError):
            raise GuardrailError("connection_failed", retryable=True) from None
        except Unavailable:
            raise GuardrailError("provider_unavailable", retryable=True) from None
        return result(response, request_id, injection=True)

    async def aclose(self):
        await self.client.aclose()


class GuardrailClient:
    def __init__(self, connection, *, transport=None):
        from openaidr_api_client.client import SyncIntelligenceClient

        self.client = SyncIntelligenceClient.from_connection(connection, transport=transport)

    @measured("guardrail")
    def assess(self, state, *, request_id, company_policy="", timeout=None, max_credits=None):
        payload, seconds = request(state, company_policy, timeout)
        if max_credits is not None:
            microcredits(max_credits)
            payload["max_credits"] = max_credits
        try:
            response = self.client.request("/v1/services/guardrail/assess", payload, MAX_RESPONSE_BYTES, seconds, request_id=request_id)
        except (httpx.RequestError, TimeoutError):
            raise GuardrailError("connection_failed", retryable=True) from None
        except Unavailable:
            raise GuardrailError("provider_unavailable", retryable=True) from None
        return result(response, request_id)

    @measured("guardrail")
    def assess_injection(self, state, *, request_id, timeout=None):
        payload, seconds = injection_request(state, timeout)
        try:
            response = self.client.request("/v1/services/guardrail/injection", payload,
                                           MAX_RESPONSE_BYTES, seconds, request_id=request_id)
        except (httpx.RequestError, TimeoutError):
            raise GuardrailError("connection_failed", retryable=True) from None
        except Unavailable:
            raise GuardrailError("provider_unavailable", retryable=True) from None
        return result(response, request_id, injection=True)

    def close(self):
        self.client.close()
