"""Capability clients using the shared tenant-bound Intelligence transport."""
