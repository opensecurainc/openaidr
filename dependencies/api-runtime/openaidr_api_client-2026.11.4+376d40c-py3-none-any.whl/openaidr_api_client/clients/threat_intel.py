"""Tenant-bound intelligence gateway calls with conservative response validation."""

from datetime import datetime, timezone
from urllib.parse import quote

import httpx

from openaidr_api_client.contracts.credits import BillingReceipt
from openaidr_api_client.contracts.service_threat_intel import ServiceUrlAssessment, ServicePackageAssessment

from openaidr_api_client.validation import web_risk as links, osv
from openaidr_api_client.client import IntelligenceClient, Unavailable
from openaidr_api_client.latency import measured, failed
from openaidr_api_client.client import TOKEN as TOKEN, validate_configuration as validate_configuration

FAILURES = (httpx.HTTPError, ValueError, TypeError, KeyError, AttributeError,
            RecursionError, OverflowError, TimeoutError, osv.Unavailable)
PACKAGE_TIMEOUT = 25


def timestamp(value):
    if not isinstance(value, str):
        raise osv.Unavailable("Invalid intelligence timestamp")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            raise ValueError
        return parsed.astimezone(timezone.utc)
    except (ValueError, OverflowError):
        raise osv.Unavailable("Invalid intelligence timestamp") from None


def findings(value):
    if not isinstance(value, list) or len(value) > osv.MAX_ADVISORIES:
        raise osv.Unavailable("Invalid intelligence findings")
    for item in value:
        if not isinstance(item, dict) or not isinstance(item.get("id"), str) or not osv.ID.fullmatch(item["id"]):
            raise osv.Unavailable("Invalid intelligence advisory")
        for field in ("aliases", "source_ids"):
            entries = item.get(field)
            if (not isinstance(entries, list) or len(entries) > osv.MAX_ADVISORIES
                    or (field == "source_ids" and not entries)
                    or any(not isinstance(entry, str) or not osv.ID.fullmatch(entry) for entry in entries)):
                raise osv.Unavailable("Invalid intelligence advisory identities")
        fixes, vectors = item.get("fixed_versions"), item.get("severity_vectors")
        if (item.get("severity") not in ("critical", "high", "medium", "low", "unknown")
                or not isinstance(item.get("summary"), str) or len(item["summary"]) > 2048
                or not isinstance(fixes, list) or len(fixes) > osv.MAX_ADVISORIES
                or any(not isinstance(fixed, str) or len(fixed) > 256 for fixed in fixes)
                or not isinstance(vectors, list) or len(vectors) > 8
                or any(not isinstance(vector, dict) or not isinstance(vector.get("type"), str)
                       or len(vector["type"]) > 128 or not isinstance(vector.get("score"), str)
                       or len(vector["score"]) > 512 for vector in vectors)
                or item.get("url") not in ["https://osv.dev/vulnerability/" + quote(ident, safe="")
                                          for ident in item["source_ids"]]):
            raise osv.Unavailable("Invalid intelligence advisory details")
    return value


async def billing(value, service, request_id, receipt):
    parsed = BillingReceipt.model_validate(value.get("billing")).model_dump()
    if parsed["request_id"] != request_id or parsed["service"] != service:
        raise osv.Unavailable("Intelligence receipt identity mismatch")
    if receipt is not None:
        await receipt(parsed)


class ThreatIntelClient(IntelligenceClient):
    async def request(self, path, payload, limit, timeout, *, request_id):
        try:
            return await super().request(path, payload, limit, timeout, request_id=request_id)
        except Unavailable as error:
            raise osv.Unavailable(str(error)) from None

    @measured("urls")
    async def assess(self, tenant, actions, availability="available", *, request_id, receipt=None):
        urls, skipped = links.extract_urls(actions)
        result = {"profile": "url-reputation.1", "status": "no_urls", "checked": 0,
                  "skipped": skipped, "failed": 0, "matches": [], "reasons": []}
        reasons = {"urls_skipped"} if skipped else set()
        if availability in ("content_redacted", "content_truncated", "unsupported_evidence"):
            reasons.add(availability)
        if urls:
            try:
                if str(tenant) != self.tenant_id:
                    raise osv.Unavailable("Intelligence tenant mismatch")
                value = await self.request("/v1/services/urls/check", {"urls": urls}, 64 << 10, links.LOOKUP_TIMEOUT, request_id=request_id)
                await billing(value, "url_reputation", request_id, receipt)
                value = ServiceUrlAssessment.model_validate(value).model_dump()
                counts = [value.get(field) for field in ("checked", "skipped", "failed")]
                matches, reported = value.get("matches"), value.get("reasons")
                if (any(type(count) is not int or count < 0 for count in counts) or sum(counts) != len(urls)
                        or not isinstance(matches, list) or len(matches) > value["checked"]
                        or not isinstance(reported, list) or len(reported) > 8
                        or any(reason not in ("urls_skipped", "timeout", "provider_unavailable", "connection_failed", "invalid_response")
                               for reason in reported)
                        or timestamp(value.get("checked_at")) > datetime.now(timezone.utc)):
                    raise osv.Unavailable("Invalid URL assessment")
                seen = set()
                for match in matches:
                    if (not isinstance(match, dict) or match.get("url") not in urls or match["url"] in seen
                            or not isinstance(match.get("threat_types"), list) or not match["threat_types"]
                            or any(threat not in links.THREAT_TYPES for threat in match["threat_types"])):
                        raise osv.Unavailable("Invalid URL match")
                    links._expiry(match["expires_at"])
                    seen.add(match["url"])
                expected = ("matched" if matches else "partial" if reported and value["checked"]
                            else "unavailable" if reported else "not_listed")
                if (value.get("status") != expected or (value["failed"] and not reported)
                        or (value["skipped"] and "urls_skipped" not in reported)):
                    raise osv.Unavailable("Inconsistent URL assessment")
                result.update(checked=value["checked"], skipped=skipped + value["skipped"],
                              failed=value["failed"], matches=matches)
                reasons.update(reported)
            except FAILURES as error:
                failed(error)
                result["failed"] = len(urls)
                reasons.add("intelligence_unavailable")
        result["reasons"] = sorted(reasons)
        result["status"] = ("matched" if result["matches"] else "partial" if reasons and result["checked"]
                            else "unavailable" if reasons else "not_listed" if urls else "no_urls")
        return result

    @measured("packages")
    async def packages(self, queries, *, request_id, receipt=None):
        if not 1 <= len(queries) <= osv.BATCH:
            raise osv.Unavailable("Invalid package count")
        packages = []
        for query in queries:
            package = query.get("package", {})
            row = {"ecosystem": str(package.get("ecosystem", "")).lower(),
                   "identifier": package.get("name"), "version": query.get("version")}
            if osv.package_query(row)[0] != query:
                raise osv.Unavailable("Invalid package identity")
            packages.append({"ecosystem": row["ecosystem"], "name": row["identifier"], "version": row["version"]})
        value = await self.request("/v1/services/packages/check", {"packages": packages}, osv.MAX_RESPONSE, PACKAGE_TIMEOUT, request_id=request_id)
        await billing(value, "package_vulnerabilities", request_id, receipt)
        value = ServicePackageAssessment.model_validate(value).model_dump()
        results = value.get("results")
        if not isinstance(results, list) or len(results) != len(queries):
            raise osv.Unavailable("Invalid package assessments")
        stamp = datetime.now(timezone.utc)
        for item, query in zip(results, queries):
            if not isinstance(item, dict) or item.get("query") != query:
                raise osv.Unavailable("Package assessment does not match request")
            if item.get("status") == "unavailable":
                if item.get("findings") != [] or item.get("checked_at") is not None or item.get("expires_at") is not None:
                    raise osv.Unavailable("Invalid unavailable assessment")
                item["reason"] = "Intelligence assessment unavailable"
            elif item.get("status") == "complete":
                checked, expires = timestamp(item.get("checked_at")), timestamp(item.get("expires_at"))
                # The receiver's contract is exactly 24 hours. This also keeps
                # existing database reads (checked_at + REFRESH) conservative.
                if not checked <= stamp < expires or expires != checked + osv.REFRESH:
                    raise osv.Unavailable("Expired or inconsistent package assessment")
                findings(item.get("findings"))
                item.update(checked_at=checked, expires_at=expires, reason="")
            else:
                raise osv.Unavailable("Unknown package assessment status")
        return results
