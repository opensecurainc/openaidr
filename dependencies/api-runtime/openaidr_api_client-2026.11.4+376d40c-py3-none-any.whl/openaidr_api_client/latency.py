"""Best-effort timing reports. No reporting work is awaited by an SDK call."""

import asyncio
from collections import deque
from contextlib import contextmanager, suppress
from contextvars import ContextVar
from functools import wraps
import inspect
import math
import os
import time

import httpx

from .contracts import latency as wire

_call = ContextVar("sdk_latency_call", default=None)
INTERVAL = 5
REPORT_TIMEOUT = 1


def measured(route=None):
    """Measure the outer SDK call, including typed response validation."""
    def decorate(function):
        first_parameter = next(iter(inspect.signature(function).parameters))
        @contextmanager
        def timing(owner, args, kwargs):
            client = owner if hasattr(owner, "_record_latency") else getattr(owner, "client", None)
            if not hasattr(client, "_record_latency"):
                yield
                return
            previous = _call.get()
            if previous is not None and getattr(previous["client"], "_client", previous["client"]) is getattr(client, "_client", client):
                try:
                    yield
                except BaseException as error:
                    previous["outcome"] = outcome(error)
                    raise
                return
            state = dict(client=client, route=route or wire.route(args[0] if args else kwargs.get("path")),
                         started=time.monotonic(), sent=False, outcome="success")
            token = _call.set(state)
            try:
                yield
            except BaseException as error:
                if state["outcome"] == "success":
                    state["outcome"] = outcome(error)
                raise
            finally:
                _call.reset(token)
                seconds = time.monotonic() - state["started"]
                if state["sent"] and state["route"] and math.isfinite(seconds) and 0 <= seconds <= 300:
                    with suppress(Exception):
                        client._record_latency(dict(route=state["route"], seconds=seconds, outcome=state["outcome"]))

        if inspect.iscoroutinefunction(function):
            @wraps(function)
            async def wrapped(*args, **kwargs):
                owner = args[0] if args else kwargs.get(first_parameter)
                with timing(owner, args[1:], kwargs):
                    return await function(*args, **kwargs)
        else:
            @wraps(function)
            def wrapped(*args, **kwargs):
                owner = args[0] if args else kwargs.get(first_parameter)
                with timing(owner, args[1:], kwargs):
                    return function(*args, **kwargs)
        return wrapped
    return decorate


def outcome(error):
    if isinstance(error, asyncio.CancelledError):
        return "cancelled"
    if isinstance(error, (TimeoutError, httpx.TimeoutException)):
        return "timeout"
    return "error"


def sent():
    state = _call.get()
    if state is not None:
        state["sent"] = True


def failed(error):
    state = _call.get()
    if state is not None and state["outcome"] == "success":
        state["outcome"] = outcome(error)


class Reporter:
    def __init__(self, client):
        self.client = client
        self.enabled = False
        self.allowed = os.environ.get("OPENAIDR_SDK_LATENCY", "true").lower() != "false"
        self.pending = deque(maxlen=256)
        self.task = None
        self.closed = False

    def advertised(self, response):
        if self.allowed and response.headers.get(wire.HEADER) == "1":
            self.enabled = True

    def record(self, sample):
        if not self.enabled or self.closed:
            return
        self.pending.append(sample)
        if self.task is None or self.task.done():
            self.task = asyncio.create_task(self.run())

    async def send(self):
        samples = [self.pending.popleft() for _ in range(min(len(self.pending), wire.MAX_SAMPLES))]
        if not samples:
            return
        try:
            async with asyncio.timeout(REPORT_TIMEOUT):
                async with self.client.stream("POST", wire.PATH, json={"samples": samples},
                                              timeout=REPORT_TIMEOUT) as response:
                    # Never read an unbounded telemetry response or retry a batch.
                    if response.status_code in (401, 403, 404, 405):
                        self.enabled = False
                        self.pending.clear()
        except Exception:
            pass

    async def run(self):
        try:
            while self.pending and self.enabled:
                await asyncio.sleep(INTERVAL)
                await self.send()
        except Exception:
            self.pending.clear()

    async def close(self):
        self.closed = True
        try:
            if self.task is not None:
                self.task.cancel()
                with suppress(asyncio.CancelledError):
                    await self.task
            # One bounded final batch supports short-lived callers. Remaining
            # samples are dropped without extending a business deadline.
            if self.enabled:
                await self.send()
        finally:
            self.pending.clear()
            await self.client.aclose()


class BorrowedTransport(httpx.AsyncBaseTransport):
    """The business client retains ownership of a caller-supplied transport."""

    def __init__(self, transport):
        self.transport = transport

    async def handle_async_request(self, request):
        return await self.transport.handle_async_request(request)
