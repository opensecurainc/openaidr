"""One tenant-bound, verified connection to local or hosted intelligence."""

import asyncio
from dataclasses import dataclass, field
from collections import OrderedDict
from enum import Enum
import hashlib
import json
from pathlib import Path
import re
import ssl
import threading
from uuid import UUID

import httpx
from anyio.from_thread import start_blocking_portal

from openaidr_api_client.contracts.origin import browser_origin
from openaidr_api_client.contracts.routes import public_path
from openaidr_api_client import latency

TOKEN = re.compile(r"oasc_[0-9a-f]{32}\.[A-Za-z0-9_-]{43}\Z")


class ServiceErrorCode(str, Enum):
    JOB_OWNER_UNAVAILABLE = "job_owner_unavailable"
    JOB_STORAGE_UNAVAILABLE = "job_storage_unavailable"
    REQUEST_CAPACITY_UNAVAILABLE = "request_capacity_unavailable"
    INVALID_API_KEY = "invalid_api_key"
    INVALID_REQUEST = "invalid_request"
    INVALID_REQUEST_IDENTITY = "invalid_request_identity"
    BODY_TIMEOUT = "body_timeout"


async def _error_code(response):
    # Retain only recognized machine codes, never arbitrary response text.
    if (response.headers.get("content-type", "").split(";")[0].strip().lower() != "application/json"
            or response.headers.get("content-encoding", "identity") != "identity"):
        return None
    body = bytearray()
    try:
        async for chunk in response.aiter_bytes():
            if len(body) + len(chunk) > 4096:
                return None
            body.extend(chunk)
        value = json.loads(body)
        if isinstance(value, dict) and isinstance(value.get("error"), str):
            return ServiceErrorCode(value["error"])
    except (ValueError, RecursionError, httpx.TransportError):
        pass
    return None


class Unavailable(Exception):
    def __init__(self, message, *, status_code=None, retry_after=None, error_code=None):
        super().__init__(message)
        self.status_code = status_code
        # Only a short Retry-After header is retained, never a response body.
        self.retry_after = retry_after if isinstance(retry_after, str) and len(retry_after) <= 80 else None
        self.error_code = error_code if isinstance(error_code, ServiceErrorCode) else None


def validate_configuration(origin, api_key, tenant_id):
    try:
        tenant = str(UUID(tenant_id))
        if (browser_origin(origin) != origin or not origin.startswith("https://")
                or not TOKEN.fullmatch(api_key)):
            raise ValueError
    except (ValueError, TypeError, AttributeError):
        raise ValueError("Intelligence requires an exact HTTPS origin, tenant API key, and tenant UUID") from None
    return tenant


@dataclass(frozen=True)
class Connection:
    origin: str
    api_key: str = field(repr=False)
    tenant_id: str
    ca_file: str = ""

    def __post_init__(self):
        object.__setattr__(self, "tenant_id", validate_configuration(self.origin, self.api_key, self.tenant_id))
        self.verify()

    def verify(self):
        if not self.ca_file:
            return True
        try:
            return ssl.create_default_context(cafile=self.ca_file)
        except (OSError, ValueError, TypeError):
            raise ValueError("Intelligence CA file must be a readable PEM trust bundle") from None

    def fingerprint(self):
        trust = Path(self.ca_file).read_bytes() if self.ca_file else b"default public trust"
        # Preserve the canonical connection identity used by retained jobs and receipts.
        identity = (self.origin, self.tenant_id, self.api_key, True,
                    hashlib.sha256(trust).hexdigest())
        return hashlib.sha256(json.dumps(identity).encode()).hexdigest()

    @classmethod
    def from_config(cls, config):
        if isinstance(config, cls):
            return config
        current = (getattr(config, "intelligence_origin", ""), getattr(config, "intelligence_api_key", ""))
        legacy = (getattr(config, "threat_intel_origin", ""), getattr(config, "threat_intel_api_key", ""))
        ca_file = getattr(config, "intelligence_ca_file", "")
        if any(legacy) and current != legacy:
            raise ValueError("Replace legacy threat-only settings with the complete Intelligence origin and API key pair (OPENAIDR_INTELLIGENCE_ORIGIN)")
        origin, key = current
        if not origin and not key and not ca_file:
            return None
        return cls(origin, key, config.tenant_id, ca_file)


class IntelligenceClient:
    def __init__(self, origin, api_key, tenant_id, transport=None, *, ca_file=""):
        self.connection = Connection(origin, api_key, tenant_id, ca_file)
        self.tenant_id = self.connection.tenant_id
        self._investigation_affinity = OrderedDict()
        options = dict(
            base_url=origin, verify=self.connection.verify(),
            trust_env=False, follow_redirects=False,
            headers={"Authorization": "Bearer " + api_key, "Accept-Encoding": "identity",
                     "X-OpenSecura-Tenant-ID": self.tenant_id},
        )
        self.client = httpx.AsyncClient(
            **options, transport=transport,
            timeout=25, limits=httpx.Limits(max_connections=8, max_keepalive_connections=8),
        )
        self._latency = latency.Reporter(httpx.AsyncClient(
            **options, transport=latency.BorrowedTransport(transport) if transport is not None else None,
            timeout=latency.REPORT_TIMEOUT, limits=httpx.Limits(max_connections=1, max_keepalive_connections=1)))

    def _record_latency(self, sample):
        self._latency.record(sample)

    @classmethod
    def from_connection(cls, connection, *, transport=None):
        return cls(connection.origin, connection.api_key, connection.tenant_id,
                   transport=transport, ca_file=connection.ca_file)

    async def aclose(self):
        try:
            await self._latency.close()
        finally:
            await self.client.aclose()

    @latency.measured()
    async def request(self, path, payload, limit, timeout, *, method="POST", accepted_status=(200,), decoder=json.loads, params=None, request_id=None):
        # Capability paths are relative to the selected origin. Never forward
        # this tenant credential to a URL supplied by a service response.
        if (not isinstance(path, str) or not public_path(path)
                or "?" in path or "#" in path
                or method not in ("GET", "POST")):
            raise Unavailable("Invalid intelligence service path")
        if params is not None:
            from .contracts.credits import RANGES
            if (path != "/v1/credits" or method != "GET" or not isinstance(params, dict)
                    or set(params) != {"range"} or not isinstance(params["range"], str) or params["range"] not in RANGES):
                raise Unavailable("Invalid intelligence service query")
        if request_id is not None:
            try:
                if not isinstance(request_id, str) or str(UUID(request_id)) != request_id:
                    raise ValueError
            except (ValueError, AttributeError):
                raise ValueError("Invalid service request identity") from None
        headers = {"Idempotency-Key": request_id} if request_id is not None else {}
        investigation_id = request_id if path == '/v1/investigations' else None
        match = re.fullmatch(r'/v1/investigations/([0-9a-f-]{36})(?:/cancel)?', path)
        if match:
            investigation_id = match[1]
        if investigation_id in self._investigation_affinity:
            headers['X-Investigation-Affinity'] = self._investigation_affinity[investigation_id]
        async with asyncio.timeout(timeout):
            latency.sent()
            async with self.client.stream(method, path, json=payload, params=params, timeout=timeout, headers=headers) as response:
                self._latency.advertised(response)
                if response.status_code not in accepted_status:
                    raise Unavailable("Intelligence service unavailable", status_code=response.status_code,
                                      retry_after=response.headers.get("retry-after"),
                                      error_code=await _error_code(response))
                if response.headers.get("content-encoding", "identity") != "identity":
                    raise Unavailable("Intelligence service unavailable")
                body = bytearray()
                async for chunk in response.aiter_bytes():
                    body.extend(chunk)
                    if len(body) > limit:
                        raise Unavailable("Intelligence response exceeds limit")
        try:
            value = decoder(body)
        except (ValueError, RecursionError):
            raise Unavailable("Invalid intelligence response") from None
        if not isinstance(value, dict):
            raise Unavailable("Invalid intelligence response")
        affinity = response.headers.get('x-investigation-affinity', '')
        if (investigation_id and value.get('id') == investigation_id
                and re.fullmatch(r'[A-Za-z0-9_-]{1,900}\.[a-f0-9]{64}', affinity)):
            self._investigation_affinity[investigation_id] = affinity
            self._investigation_affinity.move_to_end(investigation_id)
            while len(self._investigation_affinity) > 1024:
                self._investigation_affinity.popitem(last=False)
        return value

    @latency.measured("other")
    async def credits(self, range_name="24h"):
        from .contracts.credits import CreditSnapshot, RANGES
        if not isinstance(range_name, str) or range_name not in RANGES:
            raise ValueError("Invalid credit range")
        value = await self.request("/v1/credits", None, 512 << 10, 10,
                                   method="GET", params={"range": range_name})
        try:
            snapshot = CreditSnapshot.model_validate(value)
            if snapshot.tenant_id != self.tenant_id:
                raise ValueError("Credit tenant differs")
            from .contracts.credits import utc
            if (snapshot.bucket_seconds != RANGES[range_name][1]
                    or (utc(snapshot.until) - utc(snapshot.since)).total_seconds() != RANGES[range_name][0]):
                raise ValueError("Credit window differs")
        except ValueError:
            raise Unavailable("Invalid credit response") from None
        return snapshot


class SyncIntelligenceClient:
    """Keep synchronous callers on the same bounded async transport and loop."""

    def __init__(self, origin, api_key, tenant_id, transport=None, *, ca_file=""):
        self.connection = Connection(origin, api_key, tenant_id, ca_file)
        self.tenant_id = self.connection.tenant_id
        self._lock, self._closed = threading.Lock(), False
        self._manager = start_blocking_portal(name="openaidr-intelligence")
        self._portal = self._manager.__enter__()
        try:
            self._client = self._portal.call(
                lambda: IntelligenceClient.from_connection(self.connection, transport=transport))
            self._latency_loop = self._portal.call(asyncio.get_running_loop)
        except BaseException:
            self._manager.__exit__(None, None, None)
            raise

    @classmethod
    def from_connection(cls, connection, *, transport=None):
        return cls(connection.origin, connection.api_key, connection.tenant_id,
                   transport=transport, ca_file=connection.ca_file)

    def _record_latency(self, sample):
        if self._client._latency.enabled and not self._closed:
            self._latency_loop.call_soon_threadsafe(self._client._record_latency, sample)

    @latency.measured()
    def request(self, path, payload, limit, timeout, **kwargs):
        with self._lock:
            if self._closed:
                raise Unavailable("Intelligence client is closed")
            operation = self._portal.start_task_soon(
                lambda: self._client.request(path, payload, limit, timeout, **kwargs))
        return operation.result()

    @latency.measured("other")
    def credits(self, range_name="24h"):
        with self._lock:
            if self._closed:
                raise Unavailable("Intelligence client is closed")
            operation = self._portal.start_task_soon(self._client.credits, range_name)
        return operation.result()

    def close(self):
        with self._lock:
            if self._closed:
                return
            self._closed = True
        try:
            self._portal.call(self._client.aclose)
        finally:
            self._portal.call(self._portal.stop, True)
            self._manager.__exit__(None, None, None)
