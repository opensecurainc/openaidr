"""Strict requests and extension-tolerant response readers."""

from typing import Annotated
from pydantic import BaseModel, ConfigDict, Field


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, regex_engine="python-re")


class ResponseModel(Model):
    """Read extensions without changing the fields promised to older readers."""

    model_config = ConfigDict(extra="ignore", json_schema_extra={"additionalProperties": False})


Timestamp = Annotated[str, Field(json_schema_extra={"format": "date-time"})]
