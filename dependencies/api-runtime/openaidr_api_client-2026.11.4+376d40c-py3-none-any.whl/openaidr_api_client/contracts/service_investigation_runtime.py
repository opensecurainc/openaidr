"""Customer investigation evidence constraints and report validation."""

import hashlib
import json
import uuid

from openaidr_api_client.contracts.detection import DETECTION_CATEGORIES, SEVERITIES, SESSION_GAPS

REPORT_VERSION = 4


FRAGMENT_BYTES = 32 << 10


CHUNK_BYTES = 64 << 10


RESULT_BYTES = 64 << 10


READ_BYTES = 32 << 10


MAX_INTEGER = (1 << 53) - 1


STOP_CODES = frozenset(
    (
        "scope_unavailable",
        "claim_expired",
        "settings_changed",
        "budget_exhausted",
        "service_unavailable",
        "runtime_unavailable",
        "invalid_result",
        "incomplete_coverage",
        "request_replayed",
        "invalid_request",
        "cancelled",
        "internal_error",
        "service_contract_violation",
    )
)


GAPS = sorted(SESSION_GAPS | {"insufficient_context", "unknown_outcome"})


class InvestigationStopped(RuntimeError):
    def __init__(self, code):
        self.code = code if code in STOP_CODES else "internal_error"
        super().__init__(self.code)


def canonical_json(value):
    try:
        return json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode()
    except (TypeError, ValueError, UnicodeError, RecursionError):
        raise InvestigationStopped("invalid_request") from None


def _digest(value):
    return hashlib.sha256(canonical_json(value)).hexdigest()


def _need(value, code="invalid_request"):
    if not value:
        raise InvestigationStopped(code)


def _uuid(value):
    try:
        return str(uuid.UUID(value))
    except (ValueError, TypeError, AttributeError):
        raise InvestigationStopped("invalid_request") from None


def _object(properties, required=None):
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties) if required is None else required,
        "additionalProperties": False,
    }


def _string(maximum=4000, **extra):
    return {"type": "string", "maxLength": maximum, **extra}


_UUID_SCHEMA = _string(36, format="uuid")


_REF = {
    "anyOf": [
        _object(
            {
                "source": {"type": "string", "const": "target"},
                "ordinal": {"type": "integer", "minimum": 1},
                "start": {"type": "integer", "minimum": 0},
                "end": {"type": "integer", "minimum": 1},
            }
        ),
        _object(
            {
                "source": {"type": "string", "const": "history"},
                "read_id": _UUID_SCHEMA,
                "item": {"type": "integer", "minimum": 0},
            }
        ),
    ]
}


_CONFIDENCE = {"type": "string", "enum": ["high", "medium", "low"]}


_INDICES = {"type": "array", "maxItems": 20,
            "items": {"type": "integer", "minimum": 0, "maximum": 99}}


_AUTHORIZATION = _object({
    "assessment": _string(2000, minLength=1),
    "policy_basis": _string(2000),
    "policy_quote": _string(2000),
    "policy_revision": {"type": "integer", "minimum": 0},
    "evidence_indices": _INDICES,
})


_RECOMMENDATION = _object({
    "priority": {"type": "string", "enum": ["urgent", "high", "normal", "low"]},
    "action": _string(1000, minLength=1),
    "rationale": _string(1000, minLength=1),
})


_TIMELINE = {"type": "array", "maxItems": 30, "items": _object({
    "description": _string(1000, minLength=1),
    "evidence_indices": {**_INDICES, "minItems": 1},
})}


_IMPACT = _object({
    "observed": _string(2000, minLength=1),
    "potential": _string(2000, minLength=1),
})


_FINDING = _object(
    {
        "category": {"type": "string", "enum": list(DETECTION_CATEGORIES)},
        "tags": {"type": "array", "maxItems": 4,
                 "items": {"type": "string", "enum": list(DETECTION_CATEGORIES)}},
        "confidence": _CONFIDENCE,
        "authorization": _AUTHORIZATION,
        "alternative_explanations": {
            "type": "array", "maxItems": 10, "items": _string(1000, minLength=1),
        },
        "severity": {"type": "string", "enum": list(SEVERITIES)},
        "title": _string(200, minLength=1),
        "explanation": _string(4000, minLength=1),
        "severity_rationale": _string(2000, minLength=1),
        "timeline": {
            "type": "array", "minItems": 1, "maxItems": 20,
            "items": _object({
                "description": _string(1000, minLength=1),
                "evidence_indices": {
                    "type": "array", "minItems": 1, "maxItems": 10,
                    "items": {"type": "integer", "minimum": 0, "maximum": 99},
                },
            }),
        },
        "impact": _object({
            "observed": _string(2000, minLength=1),
            "potential": _string(2000, minLength=1),
        }),
        "recommended_actions": {
            "type": "array", "maxItems": 8, "items": _RECOMMENDATION,
        },
        "uncertainties": {
            "type": "array", "maxItems": 10, "items": _string(1000, minLength=1),
        },
        "evidence": {"type": "array", "items": _REF, "minItems": 1, "maxItems": 100},
        "action_outcomes": {
            "type": "array",
            "maxItems": 100,
            "items": _object(
                {
                    "logical_id": _string(128, minLength=1),
                    "execution": {
                        "type": "string",
                        "enum": [
                            "attempted",
                            "not_executed",
                            "succeeded",
                            "failed",
                            "uncertain",
                        ],
                    },
                    "authorization": {
                        "type": "string",
                        "enum": ["approved", "rejected", "revoked", "not_recorded"],
                    },
                }
            ),
        },
    }
)


REPORT_FIELDS = _object(
    {
        "status": {"type": "string", "enum": ["finding", "no_finding", "inconclusive"]},
        "verdict": {"anyOf": [
            {"type": "string", "enum": ["true_positive", "false_positive", "true_positive_non_malicious"]},
            {"type": "null"},
        ]},
        "title": _string(200, minLength=1),
        "conclusion": _string(4000, minLength=1),
        "summary": _string(4000, minLength=1),
        "confidence": _CONFIDENCE,
        "timeline": _TIMELINE,
        "authorization": _AUTHORIZATION,
        "impact": _IMPACT,
        "recommendations": {"type": "array", "maxItems": 12, "items": _RECOMMENDATION},
        "alternative_explanations": {
            "type": "array", "maxItems": 12, "items": _string(1000, minLength=1),
        },
        "limitations": {"type": "array", "maxItems": 20, "items": _string(1000, minLength=1)},
        "evidence": {"type": "array", "items": _REF, "maxItems": 100},
        "findings": {"type": "array", "items": _FINDING, "maxItems": 20},
        "gaps": {
            "type": "array",
            "items": {"type": "string", "enum": GAPS},
            "maxItems": 32,
        },
    }
)


READ_ARGUMENTS = {
    "search_sessions": _object({
        "product": _string(128), "since": _string(64), "until": _string(64),
        "cursor": _string(36), "limit": {"type": "integer", "minimum": 1, "maximum": 20},
    }, []),
    "read_session": _object({
        "session_id": _UUID_SCHEMA,
        "snapshot_id": {"anyOf": [_UUID_SCHEMA, {"type": "null"}]},
        "cursor": _string(36),
    }, ["session_id"]),
}


def _shape(schema, value):
    if "anyOf" in schema:
        return any(_shape(option, value) for option in schema["anyOf"])
    if "const" in schema and value != schema["const"]:
        return False
    if "enum" in schema and value not in schema["enum"]:
        return False
    kind = schema.get("type")
    if kind == "object":
        return (
            isinstance(value, dict)
            and set(value) <= set(schema["properties"])
            and set(schema["required"]) <= set(value)
            and all(
                _shape(schema["properties"][key], item) for key, item in value.items()
            )
        )
    if kind == "array":
        return (
            isinstance(value, list)
            and schema.get("minItems", 0)
            <= len(value)
            <= schema.get("maxItems", MAX_INTEGER)
            and all(_shape(schema["items"], item) for item in value)
        )
    if kind == "string":
        if not isinstance(value, str) or not schema.get("minLength", 0) <= len(
            value
        ) <= schema.get("maxLength", MAX_INTEGER):
            return False
        if schema.get("format") == "uuid":
            try:
                return str(uuid.UUID(value)) == value
            except (ValueError, AttributeError):
                return False
    if kind == "integer":
        return type(value) is int and schema.get("minimum", 0) <= value <= schema.get(
            "maximum", MAX_INTEGER
        )
    if kind == "null":
        return value is None
    return True


def valid_result(value):
    return _shape(REPORT_FIELDS, value)


def valid_read_arguments(name, arguments):
    schema = READ_ARGUMENTS.get(name) if isinstance(name, str) else None
    return schema is not None and _shape(schema, arguments)
