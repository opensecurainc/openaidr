"""Customer URL and package results with source evidence and credit receipts."""

from typing import Annotated, Literal

from pydantic import Field

from .base import ResponseModel, Timestamp
from .credits import BillingReceipt
from .threat_intel import CompletePackage, Finding, PackageQuery
from ..validation import web_risk, osv


class ServiceUrlMatch(ResponseModel):
    url: str
    threat_types: list[Literal[*web_risk.THREAT_TYPES]] = Field(min_length=1)
    expires_at: Timestamp


class ServiceUrlAssessment(ResponseModel):
    profile: Literal["url-reputation.1"]
    status: Literal["matched", "not_listed", "partial", "unavailable", "no_urls"]
    checked: int = Field(ge=0, le=web_risk.MAX_URLS)
    skipped: int = Field(ge=0)
    failed: int = Field(ge=0, le=web_risk.MAX_URLS)
    matches: list[ServiceUrlMatch] = Field(max_length=web_risk.MAX_URLS)
    reasons: list[Literal["urls_skipped", "timeout", "provider_unavailable", "connection_failed", "invalid_response"]]
    checked_at: Timestamp
    billing: BillingReceipt


class ServiceUnavailablePackage(ResponseModel):
    query: PackageQuery
    status: Literal["unavailable"]
    findings: list[Finding] = Field(max_length=0)
    checked_at: None
    expires_at: None
    reason: Literal["Service assessment unavailable"]


class ServicePackageAssessment(ResponseModel):
    profile: Literal["package-vulnerabilities.1"]
    results: list[Annotated[CompletePackage | ServiceUnavailablePackage, Field(discriminator="status")]] = Field(
        min_length=1, max_length=osv.BATCH)
    billing: BillingReceipt
