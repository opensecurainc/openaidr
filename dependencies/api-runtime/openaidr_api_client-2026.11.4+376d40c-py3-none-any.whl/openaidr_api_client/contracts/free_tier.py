"""Free protection availability without private provider accounting."""

from typing import Literal

from pydantic import Field, field_validator, model_validator

from .base import ResponseModel
from .credits import Amount, microcredits, utc


class FreeUsage(ResponseModel):
    status: Literal['active', 'exhausted', 'disabled']
    allowance: Amount | None
    used: Amount | None
    reserved: Amount | None
    available: Amount | None
    starts_at: str | None = Field(max_length=40)
    resets_at: str | None = Field(max_length=40)
    checked_at: str = Field(max_length=40)

    @model_validator(mode='after')
    def consistent(self):
        checked = utc(self.checked_at)
        values = (self.allowance, self.used, self.reserved, self.available)
        if self.status == 'disabled':
            if any(value is not None for value in (*values, self.starts_at, self.resets_at)):
                raise ValueError('Disabled free usage has no balance')
        else:
            if any(value is None for value in (*values, self.starts_at, self.resets_at)):
                raise ValueError('Free usage is incomplete')
            total, used, reserved, available = map(microcredits, values)
            if not total or total != used + reserved + available or (self.status == 'exhausted') != (available == 0):
                raise ValueError('Free usage does not reconcile')
            if not utc(self.starts_at) <= checked < utc(self.resets_at):
                raise ValueError('Free usage period is invalid')
        return self


class FreeStatus(ResponseModel):
    tenant_id: str = Field(pattern=r"^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$")
    plan: Literal["free"]
    status: Literal["available", "exhausted", "unavailable"]
    guardrail_configured: bool
    guardrail_available: bool
    reset_at: str | None = Field(max_length=40)
    credit_status: Literal["disabled", "unconfigured", "active", "exhausted", "unavailable"] | None
    credits_per_usd: Literal["100"]

    @field_validator("reset_at")
    @classmethod
    def timestamp(cls, value):
        if value is not None:
            utc(value)
        return value

    @model_validator(mode="after")
    def availability(self):
        if self.guardrail_available != (self.status == "available"):
            raise ValueError("Inconsistent protection availability")
        if self.guardrail_available and (not self.guardrail_configured or self.credit_status not in ("disabled", "active")):
            raise ValueError("Protection availability is not confirmed")
        return self


class FreeUsageSnapshot(ResponseModel):
    tenant_id: str = Field(pattern=r"^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$")
    plan: Literal['free']
    usage: FreeUsage
