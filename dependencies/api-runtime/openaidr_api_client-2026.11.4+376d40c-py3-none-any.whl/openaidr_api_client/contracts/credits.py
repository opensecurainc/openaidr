"""Customer service credits, independent of provider identity and accounting."""

from datetime import datetime, timezone
from decimal import Decimal
import re
from typing import Annotated, Literal

from pydantic import Field, field_validator, model_validator

from .base import ResponseModel
from .capabilities import CAPABILITIES


SERVICES = CAPABILITIES
RANGES = {"24h": (86400, 3600), "30d": (2592000, 86400), "90d": (7776000, 86400)}
MAX_INTEGER = 2**53 - 1
MICROCREDITS = 1_000_000
AMOUNT_PATTERN = r"^(?:0|[1-9][0-9]{0,9})(?:\.[0-9]{1,6})?$"
Amount = Annotated[str, Field(pattern=AMOUNT_PATTERN, max_length=17)]
Count = Annotated[int, Field(ge=0, le=MAX_INTEGER)]
Service = Literal[*SERVICES]


def amount(value):
    """Use exact decimal strings at the customer boundary."""
    if type(value) is not int or not 0 <= value <= MAX_INTEGER:
        raise ValueError("Invalid credit amount")
    return format(Decimal(value) / MICROCREDITS, "f").rstrip("0").rstrip(".") if value % MICROCREDITS else str(value // MICROCREDITS)


def microcredits(value):
    if not isinstance(value, str) or not re.fullmatch(AMOUNT_PATTERN, value):
        raise ValueError("Credit amounts must be decimal strings")
    result = Decimal(value) * MICROCREDITS
    if result > MAX_INTEGER:
        raise ValueError("Credit amount exceeds limit")
    return int(result)


def utc(value):
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.utcoffset() != timezone.utc.utcoffset(parsed):
        raise ValueError("UTC timestamp required")
    return parsed


class Totals(ResponseModel):
    credits_charged: Amount | None
    operations: Count
    pending_operations: Count
    unrated_operations: Count

    @field_validator("credits_charged")
    @classmethod
    def bounded_amount(cls, value):
        if value is not None:
            microcredits(value)
        return value

    @model_validator(mode="after")
    def counts(self):
        if max(self.pending_operations, self.unrated_operations) > self.operations:
            raise ValueError("Credit coverage exceeds operations")
        return self


class ServiceTotals(Totals):
    service: Service


def unique_services(rows):
    if len({row.service for row in rows}) != len(rows):
        raise ValueError("Duplicate credit service")
    return rows


class CreditBucket(Totals):
    time: str = Field(max_length=40)
    by_service: list[ServiceTotals] = Field(max_length=len(SERVICES))

    @field_validator("time")
    @classmethod
    def timestamp(cls, value):
        utc(value)
        return value

    _services = field_validator("by_service")(unique_services)


class CreditBalance(ResponseModel):
    available: Amount | None
    reserved: Amount | None

    @field_validator("available", "reserved")
    @classmethod
    def bounded_amount(cls, value):
        if value is not None:
            microcredits(value)
        return value


class CreditSnapshot(ResponseModel):
    schema_version: Literal[1]
    tenant_id: str = Field(pattern=r"^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$")
    status: Literal["disabled", "unconfigured", "active", "exhausted"]
    rate_version: str | None = Field(min_length=1, max_length=80, pattern=r"^[a-zA-Z0-9._-]+$")
    credits_per_usd: Literal["100"]
    since: str = Field(max_length=40)
    until: str = Field(max_length=40)
    bucket_seconds: Literal[3600, 86400]
    balance: CreditBalance
    summary: Totals
    by_service: list[ServiceTotals] = Field(max_length=len(SERVICES))
    series: list[CreditBucket] = Field(max_length=91)

    _services = field_validator("by_service")(unique_services)

    @model_validator(mode="before")
    @classmethod
    def version_type(cls, value):
        if isinstance(value, dict) and type(value.get("schema_version")) is not int:
            raise ValueError("Invalid credit schema version")
        return value

    @model_validator(mode="after")
    def window(self):
        start, end = utc(self.since), utc(self.until)
        if not start < end or (end - start).total_seconds() > 90 * 86400:
            raise ValueError("Invalid credit window")
        stamps = [utc(row.time).timestamp() for row in self.series]
        if stamps != sorted(set(stamps)) or any(
            stamp % self.bucket_seconds or not start.timestamp() - self.bucket_seconds < stamp < end.timestamp()
            for stamp in stamps
        ):
            raise ValueError("Invalid credit buckets")
        if self.status in ("disabled", "unconfigured") and any(
            value is not None for value in (self.balance.available, self.balance.reserved)
        ):
            raise ValueError("Unavailable credit balance must be unknown")
        if self.status in ("active", "exhausted") and any(
            value is None for value in (self.balance.available, self.balance.reserved)
        ):
            raise ValueError("Configured credit balance is missing")
        for total, rows in ((self.summary, self.by_service), (self.summary, self.series),
                            *((bucket, bucket.by_service) for bucket in self.series)):
            for name in ("operations", "pending_operations", "unrated_operations"):
                if getattr(total, name) != sum(getattr(row, name) for row in rows):
                    raise ValueError("Inconsistent credit coverage")
            if total.credits_charged is not None and microcredits(total.credits_charged) != sum(
                microcredits(row.credits_charged) for row in rows if row.credits_charged is not None
            ):
                raise ValueError("Inconsistent credit charges")
        return self


class BillingQuote(ResponseModel):
    status: Literal["disabled", "unconfigured", "active", "exhausted"]
    rate_version: str | None = Field(min_length=1, max_length=80, pattern=r"^[a-zA-Z0-9._-]+$")
    credits_required: Amount | None

    @model_validator(mode="after")
    def known_price(self):
        if self.credits_required is not None:
            microcredits(self.credits_required)
        if self.status in ("active", "exhausted"):
            if self.credits_required is None or self.rate_version is None:
                raise ValueError("Active charging requires a price")
        elif self.credits_required is not None:
            raise ValueError("Disabled or unconfigured charging has no quote")
        return self


class BillingReceipt(ResponseModel):
    request_id: str = Field(pattern=r"^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$")
    service: Service
    state: Literal["disabled", "reserved", "settled", "pending", "released"]
    credits_reserved: Amount | None
    credits_charged: Amount | None
    rate_version: str | None = Field(min_length=1, max_length=80, pattern=r"^[a-zA-Z0-9._-]+$")

    @model_validator(mode="after")
    def accounting(self):
        reserved = microcredits(self.credits_reserved) if self.credits_reserved is not None else None
        charged = microcredits(self.credits_charged) if self.credits_charged is not None else None
        if self.state == "disabled":
            if any(value is not None for value in (reserved, charged, self.rate_version)):
                raise ValueError("Disabled charging cannot imply a price")
        elif reserved is None or self.rate_version is None:
            raise ValueError("Rated operation requires its original reservation")
        elif self.state in ("reserved", "pending") and charged is not None:
            raise ValueError("Unresolved operation cannot imply a charge")
        elif self.state == "settled" and charged != reserved:
            raise ValueError("Settled operation must use its reserved service price")
        elif self.state == "released" and charged != 0:
            raise ValueError("Released operation has no charge")
        return self
