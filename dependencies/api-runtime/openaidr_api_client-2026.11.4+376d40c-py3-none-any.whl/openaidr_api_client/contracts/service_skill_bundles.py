"""Whole-skill semantic assessments, with one service credit receipt."""

import hashlib
import json
from typing import Annotated, Any, Literal

from pydantic import ConfigDict, Field, RootModel, field_validator, model_validator

from .base import Model, ResponseModel
from .credits import BillingReceipt
from .service_skills import REVISION

PROFILE = "skill-bundle-assessment.1"
MAX_FILE = 1 << 20
MAX_BUNDLE = 4 << 20
MAX_BODY = 9 << 20


class SkillBundleFile(Model):
    path: str = Field(min_length=1, max_length=1024)
    content: str = Field(max_length=MAX_FILE)

    @field_validator("path")
    @classmethod
    def safe_path(cls, value):
        if (any(ord(c) < 32 or ord(c) == 127 or c in "\\:" for c in value)
                or any(part in ("", ".", "..") for part in value.split("/"))):
            raise ValueError("Expected a safe relative file path")
        value.encode("utf-8")
        return value

    @field_validator("content")
    @classmethod
    def bounded_content(cls, value):
        if len(value.encode("utf-8")) > MAX_FILE:
            raise ValueError("File exceeds UTF-8 byte limit")
        return value


class ServiceSkillBundleRequest(Model):
    model_config = ConfigDict(json_schema_extra={"examples": [{
        "profile": PROFILE, "revision": REVISION, "bundle_sha256": "a" * 64,
        "files": [{"path": "SKILL.md", "content": "# Example\nUse the documented command.\n"}],
        "timeout_ms": 120000,
    }]})
    profile: Literal[PROFILE]
    revision: Literal[REVISION]
    bundle_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    files: list[SkillBundleFile] = Field(min_length=1, max_length=256)
    timeout_ms: int = Field(default=120000, ge=1, le=120000)

    @model_validator(mode="after")
    def bounded_bundle(self):
        if len({item.path for item in self.files}) != len(self.files):
            raise ValueError("Duplicate file path")
        if sum(len(item.content.encode("utf-8")) for item in self.files) > MAX_BUNDLE:
            raise ValueError("Bundle exceeds UTF-8 byte limit")
        return self


def request_hash(task):
    public = ServiceSkillBundleRequest.model_validate(task).model_dump()
    return hashlib.sha256(json.dumps(public, sort_keys=True, allow_nan=False).encode()).hexdigest()


class CompletedSkillBundle(ResponseModel):
    profile: Literal[PROFILE]
    status: Literal["completed"]
    request_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    result: dict[str, Any]
    billing: BillingReceipt


class FailedSkillBundle(ResponseModel):
    profile: Literal[PROFILE]
    status: Literal["error"]
    request_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    code: Literal["timeout", "provider_unavailable", "invalid_response", "runtime_unavailable", "reservation_exceeded", "response_limit"]
    result: dict[str, Any]
    billing: BillingReceipt


class ServiceSkillBundleResponse(RootModel[Annotated[CompletedSkillBundle | FailedSkillBundle, Field(discriminator="status")]]):
    pass


def validate_response(task, value):
    parsed = ServiceSkillBundleResponse.model_validate(value).root
    if parsed.request_hash != request_hash(task):
        raise ValueError("Unbound skill bundle assessment")
    return parsed
