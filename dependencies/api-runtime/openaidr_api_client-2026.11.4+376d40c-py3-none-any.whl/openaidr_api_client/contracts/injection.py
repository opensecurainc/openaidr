"""Bounded task-context evidence and advisory task-redirection results."""

import json
from typing import Annotated, Literal

from pydantic import Field, RootModel, model_validator

from .base import Model, ResponseModel, Timestamp
from .credits import BillingReceipt
from .service_guardrail import ServiceFailedGuardrail

PROFILE = "guardrail.injection.1"
MAX_STATE_BYTES = 24_000


class InjectionToolOutput(Model):
    name: str = Field(min_length=1, max_length=128)
    output: str = Field(max_length=8000)


class InjectionToolInput(Model):
    name: str = Field(min_length=1, max_length=128)
    input: str = Field(max_length=2000)


class InjectionToolResult(Model):
    kind: Literal["tool.result"]
    tool: InjectionToolOutput


class InjectionToolCall(Model):
    kind: Literal["tool.call"]
    tool: InjectionToolInput


class InjectionResponse(Model):
    kind: Literal["response"]
    text: str = Field(max_length=2000)


class InjectionPrompt(Model):
    kind: Literal["prompt"]
    text: str = Field(min_length=1, max_length=2000,
                      description="The actual user task, supplied by the caller independently of tool output.")


class InjectionState(Model):
    target_event: InjectionToolResult
    latest_prompt: InjectionPrompt
    prior_events: list[Annotated[InjectionToolResult | InjectionToolCall | InjectionResponse,
                                 Field(discriminator="kind")]] = Field(max_length=4)
    context_limited: bool

    @model_validator(mode="after")
    def bounded_evidence(self):
        if not self.latest_prompt.text.strip() or not self.target_event.tool.output.strip():
            raise ValueError("User task and target content are required")
        values = [(self.latest_prompt.text, 2000), (self.target_event.tool.output, 8000)]
        for event in self.prior_events:
            value = event.text if event.kind == "response" else (
                event.tool.output if event.kind == "tool.result" else event.tool.input)
            values.append((value, 2000))
        if any(len(value.encode("utf-8")) > limit for value, limit in values):
            raise ValueError("Evidence exceeds its UTF-8 byte bound")
        if len(json.dumps(self.model_dump(), ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode()) > MAX_STATE_BYTES:
            raise ValueError("Evidence exceeds the state byte bound")
        return self


class ScoredInjection(ResponseModel):
    profile: Literal["guardrail.injection.1"]
    status: Literal["scored"]
    score: float = Field(ge=0, le=1, description="Task-redirection score, not a calibrated probability or enforcement decision.")
    detected: bool = Field(description="Whether the advisory score crosses this profile's fixed operating threshold.")
    assessed_at: Timestamp
    billing: BillingReceipt

    @model_validator(mode="after")
    def consistent_detection(self):
        if self.detected != (self.score > .32):
            raise ValueError("Detection does not match this profile")
        return self


class FailedInjection(ServiceFailedGuardrail):
    profile: Literal["guardrail.injection.1"]


class InjectionAssessment(RootModel[Annotated[ScoredInjection | FailedInjection, Field(discriminator="status")]]):
    """A task-context detector. It does not support context-free text or authorize actions."""
