"""Shared request limits and failures for customer generation services."""

from typing import Literal

from pydantic import Field

from .base import Model, ResponseModel
from .credits import BillingReceipt


class ServiceGenerationRequest(Model):
    timeout_ms: int = Field(default=45000, ge=1, le=45000,
                           description="Remaining caller budget, including authentication and body receipt.")



class ServiceGenerationError(ResponseModel):
    status: Literal["error"]
    code: Literal["timeout", "provider_unavailable", "invalid_response"]
    retry_after: None
    profile: Literal["assistant.1", "overview-summaries.1", "session-summaries.1", "rule-generation.1"]
    billing: BillingReceipt
