"""Strict origin parsing shared by tenant requests and service connections."""

from urllib.parse import urlsplit


def browser_origin(value: str, *, referer=False) -> str:
    """Parse an explicit HTTP origin, or the origin of a Referer URL."""
    if not value or any(ord(char) <= 32 or ord(char) == 127 for char in value):
        raise ValueError("invalid browser origin")
    if "\\" in value or "#" in value or (not referer and "?" in value):
        raise ValueError("invalid browser origin")
    parsed = urlsplit(value)
    if (
        parsed.scheme not in ("http", "https")
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or (not referer and (parsed.path or parsed.query))
        or "%" in parsed.netloc
    ):
        raise ValueError("invalid browser origin")
    host = parsed.hostname.lower()
    if ":" in host:
        host = "[" + host + "]"
    port = parsed.port
    if parsed.netloc.lower() != host + (f":{port}" if port is not None else ""):
        raise ValueError("invalid browser origin")
    suffix = (
        f":{port}"
        if port is not None and port != (443 if parsed.scheme == "https" else 80)
        else ""
    )
    return f"{parsed.scheme}://{host}{suffix}"
