"""Customer application research contracts and evidence validation."""

from copy import deepcopy
from typing import Annotated, Any, Literal

from pydantic import Field, RootModel, field_validator, model_validator

from .base import ResponseModel
from .credits import BillingReceipt
from ..validation import applications


APPLICATION_RESULT_SCHEMA = deepcopy(applications.SCHEMA)
_assessment = APPLICATION_RESULT_SCHEMA["properties"]["assessment"]
_assessment["required"].append("capability_score")
_assessment["properties"]["capability_score"] = {"type": ["integer", "null"], "minimum": 0, "maximum": 100}
_assessment["properties"]["risk"]["required"].append("provisional_score")
_assessment["properties"]["risk"]["properties"]["provisional_score"] = {"type": ["integer", "null"], "minimum": 0, "maximum": 100}


def _known_result(schema, value):
    """Project the closed research DTO, never captured evidence or open maps."""
    if isinstance(value, dict) and schema.get("additionalProperties") is False:
        properties = schema["properties"]
        return {key: _known_result(properties[key], item) for key, item in value.items() if key in properties}
    if isinstance(value, list) and schema.get("type") == "array":
        return [_known_result(schema["items"], item) for item in value]
    return value


class ServiceCompletedApplication(ResponseModel):
    profile: Literal["application-research.1"]
    status: Literal["completed"]
    evidence_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    result: dict[str, Any] = Field(json_schema_extra=APPLICATION_RESULT_SCHEMA)
    source_urls: list[Annotated[str, Field(max_length=2048)]] = Field(max_length=60)
    billing: BillingReceipt

    @field_validator("result")
    @classmethod
    def known_result(cls, value):
        return _known_result(APPLICATION_RESULT_SCHEMA, value)

    @model_validator(mode="after")
    def research(self):
        if (set(self.result) != set(applications.SCHEMA["required"])
                or any(not applications._url(url) for url in self.source_urls)
                or sorted(set(self.source_urls)) != self.source_urls):
            raise ValueError("Invalid application research")
        raw = deepcopy(self.result)
        try:
            assessment = raw["assessment"]
            capability = assessment.pop("capability_score")
            provisional = assessment["risk"].pop("provisional_score")
            if any(score is not None and (type(score) is not int or not 0 <= score <= 100)
                   for score in (capability, provisional)):
                raise ValueError("Invalid application score")
            if assessment["risk"]["score"] is None:
                assessment["risk"]["score"] = provisional
            parsed = applications.parse_classification(raw, set(self.source_urls))
            if parsed != self.result or applications.cited_urls(parsed) != self.source_urls:
                raise ValueError("Inconsistent application research")
        except (KeyError, TypeError, AttributeError):
            raise ValueError("Invalid application research") from None
        return self


class ServiceFailedApplication(ResponseModel):
    profile: Literal["application-research.1"]
    status: Literal["error"]
    evidence_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    code: Literal["provider_unavailable", "provider_rejected", "invalid_response", "timeout", "rate_limited"]
    retry_after: float | None = Field(ge=60, allow_inf_nan=False)
    billing: BillingReceipt


class ServiceApplicationAssessment(RootModel[Annotated[
        ServiceCompletedApplication | ServiceFailedApplication, Field(discriminator="status")]]):
    pass
