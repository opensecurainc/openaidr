"""Typed URL and package assessment wire schemas shared with the service."""

from typing import Annotated, Literal

from pydantic import ConfigDict, Field

from .base import Model, ResponseModel, Timestamp
from ..validation import web_risk as malicious_links, osv


def pattern(value, *, ignore_case=False):
    """Translate the provider's full-match patterns to portable JSON Schema regexes."""
    if ignore_case:
        # Python IGNORECASE also folds these four Unicode letters into [a-z].
        value = value.replace("[a-z0-9]", "[a-zA-Z0-9\u0130\u0131\u017f\u212a]")
        for word in ("post", "dev", "rc"):
            # The fixed literal segments are the only case-sensitive parts left.
            value = value.replace(word, "".join(f"[{c}{c.upper()}{'ſ' if c == 's' else ''}]" for c in word))
        value = value.replace("(?:a|b|", "(?:[aA]|[bB]|")
    # Unlike $, this also rejects a terminal newline, as re.fullmatch does.
    return "^(?:" + value + r")(?![\s\S])"


class UrlRequest(Model):
    urls: list[str] = Field(
        min_length=1, max_length=malicious_links.MAX_URLS,
        description=(f"URL text strings, each at most {malicious_links.MAX_URL_BYTES} UTF-8 bytes "
                     f"and at most {malicious_links.MAX_URL_TOTAL_BYTES} UTF-8 bytes combined. "
                     "HTTP(S) URLs are extracted, normalized, and deduplicated. Text without a URL "
                     "is accepted and may return no_urls. Private destinations and detected secrets "
                     "are skipped. These byte and normalization rules exceed JSON Schema validation."),
        json_schema_extra={"x-max-item-utf8-bytes": malicious_links.MAX_URL_BYTES,
                           "x-max-total-utf8-bytes": malicious_links.MAX_URL_TOTAL_BYTES},
    )
    model_config = ConfigDict(json_schema_extra={"examples": [{"urls": ["https://example.com/"]}]})


class NpmPackage(Model):
    ecosystem: str = Field(pattern=r"^[nN][pP][mM](?![\s\S])", description="npm, case-insensitive.")
    name: str = Field(max_length=osv.MAX_NAME, pattern=pattern(osv.NPM_NAME),
                      description="Lowercase registry name; scoped names are supported.")
    version: str = Field(max_length=osv.MAX_VERSION, pattern=pattern(osv.NPM_VERSION),
                         description="Concrete SemVer, with optional v prefix, prerelease, and build metadata.")


class PypiPackage(Model):
    ecosystem: str = Field(pattern=r"^[pP][yY][pP][iI](?![\s\S])", description="PyPI, case-insensitive.")
    name: str = Field(max_length=osv.MAX_NAME, pattern=pattern(osv.PYPI_NAME),
                      description="Registry name. Case and repeated separators normalize in the response.")
    version: str = Field(max_length=osv.MAX_VERSION, pattern=pattern(osv.PYPI_VERSION, ignore_case=True),
                         description="Concrete supported PEP 440 version. Tags, ranges, paths, and VCS references are rejected.")


class PackageRequest(Model):
    packages: list[NpmPackage | PypiPackage] = Field(
        min_length=1, max_length=osv.BATCH,
        description="All items are validated before provider work. Any invalid item rejects the whole batch.",
    )
    model_config = ConfigDict(json_schema_extra={"examples": [{"packages": [
        {"ecosystem": "npm", "name": "example", "version": "1.0.0"},
        {"ecosystem": "PyPI", "name": "sample-library", "version": "2.0"},
    ]}]})


class PackageIdentity(ResponseModel):
    ecosystem: Literal["npm", "PyPI"]
    name: str = Field(description="Canonical package name, including PyPI separator and case normalization.")


class PackageQuery(ResponseModel):
    package: PackageIdentity
    version: str = Field(description="The accepted concrete version string, retained as supplied.")


class SeverityVector(ResponseModel):
    type: str = Field(description="Provider vector type, for example CVSS_V3.")
    score: str = Field(max_length=osv.MAX_VECTOR_SCORE, description="Provider vector string; no numeric score is computed.")


class Finding(ResponseModel):
    id: str = Field(description="Representative identity after alias merging; a CVE is preferred when available.")
    aliases: list[str] = Field(description="Other linked identities, sorted and unique; excludes id.")
    source_ids: list[str] = Field(description="Sorted unique OSV records used to construct the finding.")
    summary: str = Field(max_length=osv.MAX_SUMMARY, description="Provider summary or Known vulnerability reported by OSV.")
    severity: Literal["critical", "high", "medium", "low", "unknown"] = Field(
        description="Record-level qualitative severity; highest known level wins when aliases merge. Unknown is not low risk.")
    fixed_versions: list[Annotated[str, Field(max_length=osv.MAX_VERSION)]] = Field(
        description="Sorted unique fixes for the matching package. These are not a selected upgrade recommendation.")
    severity_vectors: list[SeverityVector] = Field(max_length=osv.MAX_VECTORS,
        description="Matching-package and record-level vectors. No exploitability verdict is inferred.")
    url: str = Field(description="OSV source link using the first source_id, which can differ from id.")


class CompletePackage(ResponseModel):
    query: PackageQuery
    status: Literal["complete"]
    findings: list[Finding] = Field(description="Empty means the successful assessment found no vulnerabilities. Withdrawn advisories are omitted; aliases merge.")
    checked_at: Timestamp = Field(description="Original successful assessment time, preserved on cache hits.")
    expires_at: Timestamp = Field(description=f"Original checked_at plus {int(osv.REFRESH.total_seconds())} seconds, preserved on cache hits.")
    reason: Literal[""]
