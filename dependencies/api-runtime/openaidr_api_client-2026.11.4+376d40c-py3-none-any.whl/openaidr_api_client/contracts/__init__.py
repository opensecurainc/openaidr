"""Shared Intelligence API contracts for service and tenant callers."""
