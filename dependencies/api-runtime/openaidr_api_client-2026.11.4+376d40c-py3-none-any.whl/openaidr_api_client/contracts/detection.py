"""Shared detection categories, severity labels, and evidence gap vocabulary."""

from openaidr_common.event import EVIDENCE_GAPS

DETECTION_CATEGORIES = (
    "data_exposure",
    "destructive_activity",
    "unauthorized_actions",
    "agent_compromise",
    "acceptable_use",
)


SEVERITIES = ("critical", "high", "medium", "low", "info")


SESSION_GAPS = EVIDENCE_GAPS | {
    "backend_unavailable",
    "journal_lost",
    "unsupported_boundary",
    "unverified_history",
    "outcome_unreported",
}
