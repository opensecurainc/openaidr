"""Customer rule drafting and clarification contracts."""

from typing import Annotated, Any, Literal

from pydantic import ConfigDict, Field, RootModel, model_validator

from .base import ResponseModel
from .credits import BillingReceipt
from .errors import APIError
from .service_generation import ServiceGenerationError, ServiceGenerationRequest
from ..validation import rule_authoring


class ServiceRuleRequest(ServiceGenerationRequest):
    intent: str = Field(min_length=1, max_length=4000, pattern=r"^[^\x00]*$")
    model_config = ConfigDict(json_schema_extra={"examples": [{"intent": "Ask before deleting files."}]})



class ServiceRuleDraft(ResponseModel):
    intent: str = Field(min_length=1, max_length=4000)
    explanation: str = Field(min_length=1, max_length=1000)
    limitations: list[Annotated[str, Field(min_length=1, max_length=300)]] = Field(max_length=5)
    rule: dict[str, Any] = Field(json_schema_extra=rule_authoring.RULE_SCHEMA)
    examples: list[dict[str, Any]] = Field(min_length=2, max_length=8,
                                         json_schema_extra={"items": rule_authoring.EXAMPLE_SCHEMA})

    @model_validator(mode="after")
    def policy_fields(self):
        try:
            rule_authoring.validate_draft(self.model_dump())
        except (APIError, TypeError, KeyError):
            raise ValueError("Invalid generated rule draft") from None
        return self



class ServiceDraftResult(ResponseModel):
    status: Literal["draft"]
    draft: ServiceRuleDraft



class ServiceClarification(ResponseModel):
    status: Literal["clarify", "unsupported"]
    explanation: str = Field(min_length=1, max_length=1000)



class ServiceRuleCompleted(ResponseModel):
    profile: Literal["rule-generation.1"]
    status: Literal["completed"]
    result: Annotated[ServiceDraftResult | ServiceClarification, Field(discriminator="status")]
    billing: BillingReceipt



class ServiceRuleResponse(RootModel[Annotated[ServiceRuleCompleted | ServiceGenerationError, Field(discriminator="status")]]):
    pass
