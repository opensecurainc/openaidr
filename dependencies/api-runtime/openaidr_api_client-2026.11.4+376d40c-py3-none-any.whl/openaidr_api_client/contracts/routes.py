"""Customer service route boundary, independent of client-controlled headers."""

import re

PUBLIC_PATHS = frozenset((
    "/v1/keys/claim", "/v1/credits", "/v1/capabilities", "/v1/free/enroll", "/v1/free/status", "/v1/free/usage",
    "/v1/services/guardrail/assess", "/v1/services/apps/assess", "/v1/services/skills/assess",
    "/v1/services/guardrail/injection", "/v1/services/skills/assess-bundle", "/v1/services/skills/scan-bundle",
    "/v1/services/assistant/respond", "/v1/services/summaries/generate", "/v1/services/rules/draft",
    "/v1/services/urls/check", "/v1/services/packages/check",
    "/v1/investigations", "/v1/feedback", "/v1/telemetry/sdk-latency",
))
IDENTIFIER = r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}"
INVESTIGATION_JOB = re.compile(r"/v1/investigations/" + IDENTIFIER + r"(?:/cancel)?\Z")
FEEDBACK_DELETE = re.compile(r"/v1/feedback/" + IDENTIFIER + r"/delete\Z")


def public_path(path):
    return path in PUBLIC_PATHS or INVESTIGATION_JOB.fullmatch(path) is not None or FEEDBACK_DELETE.fullmatch(path) is not None
