"""Customer assistant requests and results."""

from typing import Annotated, Literal

from pydantic import ConfigDict, Field, RootModel

from .base import Model, ResponseModel
from .credits import BillingReceipt
from .service_generation import ServiceGenerationError, ServiceGenerationRequest


class ServiceCurrentPage(Model):
    path: str = Field(min_length=1, max_length=2048, pattern=r"^/(?!/)")
    title: str = Field(min_length=1, max_length=200)
    text: str = Field(min_length=1, max_length=20000)
    truncated: bool



class ServiceChatMessage(Model):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=8000)



class ServiceAssistantRequest(ServiceGenerationRequest):
    page: ServiceCurrentPage
    messages: list[ServiceChatMessage] = Field(min_length=1, max_length=9,
        description="Up to four alternating user/assistant turns and a final user question. User text is limited to 4000 characters; total history to 24000.")
    stream: bool = False
    model_config = ConfigDict(json_schema_extra={"examples": [{
        "page": {"path": "/overview", "title": "Overview", "text": "No findings shown.", "truncated": False},
        "messages": [{"role": "user", "content": "Summarize this page."}], "stream": False,
    }]})



class ServiceAnswer(ResponseModel):
    answer: str = Field(min_length=1, max_length=8000)



class ServiceAssistantCompleted(ResponseModel):
    profile: Literal["assistant.1"]
    status: Literal["completed"]
    result: ServiceAnswer
    billing: BillingReceipt



class ServiceAssistantResponse(RootModel[Annotated[ServiceAssistantCompleted | ServiceGenerationError, Field(discriminator="status")]]):
    pass
