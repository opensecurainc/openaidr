"""Explicit tenant feedback for evaluation, separate from model execution."""

from datetime import datetime, timezone
import hashlib
import json
from typing import Annotated, Any, Literal

from pydantic import Field, field_validator, model_validator

from .base import Model, ResponseModel

MAX_CONTENT = 256 << 10
MAX_BODY = 288 << 10
MAX_RETENTION = 30 * 86400
UUID = Annotated[str, Field(pattern=r"^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$")]
Digest = Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
Gap = Annotated[str, Field(pattern=r"^[a-z][a-z0-9_]{0,63}$")]


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def stamp(value):
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.utcoffset() != timezone.utc.utcoffset(parsed):
        raise ValueError("UTC timestamp required")
    return parsed.timestamp()


class Subject(Model):
    type: Literal["hook_check", "case"]
    id: UUID
    reviewed_revision: Digest | None


class Attribution(Model):
    kind: Literal["device", "analyst", "unknown"]
    source_id: UUID | None
    reviewer_id: UUID | None

    @model_validator(mode="after")
    def identity(self):
        if self.kind != "analyst" and self.reviewer_id is not None:
            raise ValueError("Only analyst attribution can include a reviewer identity")
        return self


class Evidence(Model):
    snapshot_id: UUID | None
    sha256: Digest | None
    content: dict[str, Any] | None
    gaps: list[Gap] = Field(max_length=32)

    @model_validator(mode="after")
    def completeness(self):
        if len(set(self.gaps)) != len(self.gaps):
            raise ValueError("Duplicate completeness flags")
        if self.content is None:
            if "content_not_shared" not in self.gaps:
                raise ValueError("Missing content must be explicit")
        elif len(canonical(self.content)) > MAX_CONTENT or digest(self.content) != self.sha256:
            raise ValueError("Evidence content exceeds its limit or does not match its hash")
        return self


class Feedback(Model):
    schema_version: Literal[1]
    feedback_id: UUID
    revision: int = Field(ge=1, le=2**31 - 1)
    feedback_type: Literal["guardrail", "detection"]
    subject: Subject
    label: Literal["correct_denial", "false_positive", "insufficient_context", "true_positive", "under_review"]
    note: str = Field(max_length=2000, pattern=r"^[^\x00]*$")
    reviewed_at: str = Field(max_length=40)
    attribution: Attribution
    evidence: Evidence
    service_request_ids: list[UUID] = Field(max_length=100)
    sharing_scope: Literal["metadata", "evidence"]
    expires_at: str = Field(max_length=40)

    @model_validator(mode="before")
    @classmethod
    def version(cls, value):
        if isinstance(value, dict) and type(value.get("schema_version")) is not int:
            raise ValueError("Invalid feedback schema version")
        return value

    @field_validator("reviewed_at", "expires_at")
    @classmethod
    def timestamp(cls, value):
        stamp(value)
        return value

    @model_validator(mode="after")
    def scope(self):
        labels = {"guardrail": {"correct_denial", "false_positive", "insufficient_context"},
                  "detection": {"true_positive", "false_positive", "under_review", "insufficient_context"}}
        if self.subject.type != {"guardrail": "hook_check", "detection": "case"}[self.feedback_type] or self.label not in labels[self.feedback_type]:
            raise ValueError("Feedback type, subject and label do not match")
        if self.sharing_scope == "metadata" and (self.evidence.content is not None or self.note
                or self.attribution.source_id is not None or self.attribution.reviewer_id is not None):
            raise ValueError("Metadata sharing excludes content, notes and actor identities")
        if self.subject.reviewed_revision is None and "legacy_unbound" not in self.evidence.gaps:
            raise ValueError("Unknown reviewed revision must be explicit")
        if not self.service_request_ids and "service_request_unavailable" not in self.evidence.gaps:
            raise ValueError("Missing service reference must be explicit")
        if len(set(self.service_request_ids)) != len(self.service_request_ids):
            raise ValueError("Duplicate service reference")
        if stamp(self.reviewed_at) >= stamp(self.expires_at):
            raise ValueError("Feedback must expire after review")
        return self


class FeedbackReceipt(ResponseModel):
    schema_version: Literal[1]
    tenant_id: UUID
    feedback_id: UUID
    revision: int = Field(ge=1, le=2**31 - 1)
    receipt_id: UUID
    request_sha256: Digest
    received_at: str
    expires_at: str


class FeedbackDeletion(ResponseModel):
    schema_version: Literal[1]
    tenant_id: UUID
    feedback_id: UUID
    status: Literal["deleted"]
    deleted_at: str
