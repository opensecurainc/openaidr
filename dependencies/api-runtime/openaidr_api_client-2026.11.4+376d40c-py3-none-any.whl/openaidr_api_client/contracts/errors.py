"""Shared validation errors for API contracts and tenant adapters."""

class APIError(Exception):
    def __init__(self, status, message, code=None):
        self.status = status
        self.message = message
        self.code = code or {
            400: "bad_request",
            401: "unauthorized",
            403: "forbidden",
            404: "not_found",
            409: "conflict",
            413: "bad_request",
            415: "bad_request",
            429: "rate_limited",
        }.get(status, "internal")
        super().__init__(message)


def require(condition, message, status=400):
    if not condition:
        raise APIError(status, message)
