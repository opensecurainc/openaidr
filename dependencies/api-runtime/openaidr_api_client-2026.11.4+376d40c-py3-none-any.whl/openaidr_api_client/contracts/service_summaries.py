"""Customer overview and session summary contracts."""

from typing import Annotated, Any, Literal

from pydantic import ConfigDict, Field, RootModel

from .base import Model, ResponseModel
from .credits import BillingReceipt
from .service_generation import ServiceGenerationError, ServiceGenerationRequest
from ..validation import overview_summary, session_activity_summaries


class ServiceSummarySource(Model):
    id: str = Field(min_length=1, max_length=20)
    path: str = Field(min_length=1, max_length=2048, pattern=r"^/(?!/)")
    title: str = Field(min_length=1, max_length=200)
    scope: str = Field(min_length=1, max_length=1000)
    captured_at: str = Field(min_length=1, max_length=80)
    status: Literal["available", "unavailable"]
    facts: dict[str, Any] = Field(description="Authorized aggregate facts, never raw records or credentials. The full source bundle is bounded to 128 KiB UTF-8 JSON.")



class ServiceOverviewRequest(ServiceGenerationRequest):
    kind: Literal["overview"]
    sources: list[ServiceSummarySource] = Field(min_length=1, max_length=overview_summary.MAX_SOURCES)



class ServiceSessionSummaryRequest(ServiceGenerationRequest):
    kind: Literal["session_activity"]
    evidence: list[dict[str, Any]] = Field(min_length=1, max_length=session_activity_summaries.MAX_RECORDS,
        description="Tenant-authorized, redacted captured activity. JSON is limited to 16000 characters; records remain untrusted evidence.")



class ServiceSummaryRequest(RootModel[Annotated[ServiceOverviewRequest | ServiceSessionSummaryRequest, Field(discriminator="kind")]]):
    model_config = ConfigDict(json_schema_extra={"examples": [{
        "kind": "session_activity", "evidence": [{"kind": "prompt", "text": "Inspect the failing build."}],
    }]})



class ServiceSummaryItem(ResponseModel):
    topic: Literal[*overview_summary.TOPICS]
    tone: Literal[*overview_summary.TONES]
    headline: str = Field(min_length=1, max_length=16)
    caption: str = Field(max_length=40)
    text: str = Field(min_length=1, max_length=150)
    detail: str = Field(min_length=1, max_length=900)
    citations: list[str] = Field(min_length=1, max_length=4)



class ServiceOverviewResult(ResponseModel):
    items: list[ServiceSummaryItem] = Field(min_length=1, max_length=6)



class ServiceSessionSummaryResult(ResponseModel):
    summary: str | None = Field(min_length=1, max_length=240)



class ServiceSummaryCompleted(ResponseModel):
    profile: Literal["overview-summaries.1", "session-summaries.1"]
    status: Literal["completed"]
    result: ServiceOverviewResult | ServiceSessionSummaryResult
    billing: BillingReceipt



class ServiceSummaryResponse(RootModel[Annotated[ServiceSummaryCompleted | ServiceGenerationError, Field(discriminator="status")]]):
    pass
