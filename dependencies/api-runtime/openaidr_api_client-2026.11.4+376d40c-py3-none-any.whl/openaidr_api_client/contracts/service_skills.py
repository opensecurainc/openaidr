"""Bounded public scanner tasks and results with service credit receipts."""

import hashlib
import json
from typing import Annotated, Any, Literal

from pydantic import ConfigDict, Field, RootModel

from .base import Model, ResponseModel
from .credits import BillingReceipt


REVISION = "cf5cac7ba5c756a6e0ebf52dc9763f49422f889f"
TASKS = ("semantic_security_discovery", "semantic_quality_policy", "semantic_developer_intent", "meta_analyzer", "mcp_tool_poisoning")


class ServiceSkillBatch(Model):
    file_path: str = Field(min_length=1, max_length=2048)
    content: str = Field(max_length=700000)
    start_line: int = Field(default=1, ge=1, le=10000000)
    end_line: int | None = Field(default=None, ge=1, le=10000000)
    findings: list[dict[str, Any]] = Field(default_factory=list, max_length=500)


class ServiceSkillRequest(Model):
    model_config = ConfigDict(json_schema_extra={"examples": [{
        "revision": REVISION, "task": "semantic_security_discovery", "bundle_sha256": "a" * 64,
        "batch": {"file_path": "SKILL.md", "content": "# Example\nUse the documented command.\n"},
        "timeout_ms": 120000,
    }]})
    revision: Literal[REVISION]
    task: Literal[*TASKS]
    bundle_sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    batch: ServiceSkillBatch
    metadata: str = Field(default="", max_length=64000)
    timeout_ms: int = Field(default=120000, ge=1, le=120000)


def request_hash(task):
    public = ServiceSkillRequest.model_validate(task).model_dump()
    return hashlib.sha256(json.dumps(public, sort_keys=True, allow_nan=False).encode()).hexdigest()


class ServiceCompletedSkill(ResponseModel):
    profile: Literal["skill-assessment.1"]
    status: Literal["completed"]
    request_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    result: dict[str, Any]
    billing: BillingReceipt


class ServiceFailedSkill(ResponseModel):
    profile: Literal["skill-assessment.1"]
    status: Literal["error"]
    request_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    code: Literal["timeout", "provider_unavailable", "invalid_response", "runtime_unavailable", "reservation_exceeded"]
    billing: BillingReceipt


class ServiceSkillResponse(RootModel[Annotated[ServiceCompletedSkill | ServiceFailedSkill, Field(discriminator="status")]]):
    pass


def validate_response(task, value):
    parsed = ServiceSkillResponse.model_validate(value).root
    if parsed.request_hash != request_hash(task):
        raise ValueError("Unbound skill assessment")
    return parsed
