"""Content-free SDK call measurements, reported after the call completes."""

from typing import Annotated, Literal
from pydantic import BaseModel, ConfigDict, Field

PATH = "/v1/telemetry/sdk-latency"
HEADER = "x-openaidr-sdk-latency"
MAX_BODY = 16384
MAX_SAMPLES = 64
ROUTES = ("capabilities", "urls", "packages", "guardrail", "applications", "assistant",
          "summaries", "rules", "skills", "investigation_create", "investigation_status",
          "investigation_cancel", "other")
OUTCOMES = ("success", "error", "timeout", "cancelled")
BOUNDS = (.01, .025, .05, .075, .1, .15, .2, .25, .3, .4, .5, .75,
          1, 1.5, 2, 3, 5, 10, 30, 60, 120, 300)


class Sample(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, allow_inf_nan=False)
    route: Literal[*ROUTES]
    seconds: Annotated[float, Field(ge=0, le=300)]
    outcome: Literal[*OUTCOMES]


class Report(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    samples: Annotated[list[Sample], Field(min_length=1, max_length=MAX_SAMPLES)]


def route(path):
    from .routes import public_path
    if not isinstance(path, str) or not public_path(path):
        return None
    if path.startswith("/v1/investigations"):
        return ("investigation_create" if path == "/v1/investigations" else
                "investigation_cancel" if path.endswith("/cancel") else "investigation_status")
    if path.startswith("/v1/feedback") or path == "/v1/credits":
        return "other"
    parts = path.split("/")
    name = parts[3] if path.startswith("/v1/services/") else parts[2]
    name = "applications" if name == "apps" else name
    return name if name in ROUTES else None
