"""Customer guardrail outcomes and service billing, without provider metadata."""

from typing import Annotated, Literal

from pydantic import Field, RootModel

from .base import ResponseModel, Timestamp
from .credits import BillingReceipt


PROFILE = "guardrail.1"
ASSESSMENT_VERSION = 1
KINDS = ("prompt", "response", "tool.call", "tool.result", "command", "file.read", "file.write", "network")
MAX_EVENT_BYTES = 8_000
MAX_STATE_BYTES = 24_000
MAX_RESPONSE_BYTES = 64_000
REQUEST_TIMEOUT = 10
MAX_PROMPT_CHARACTERS = 10_000


class GuardrailError(Exception):
    def __init__(self, code, retryable=False, retry_after=30):
        super().__init__(code)
        self.code, self.retryable, self.retry_after = code, retryable, retry_after
        self.billing = None


CATEGORIES = ("secret_exfiltration", "data_exfiltration", "supply_chain",
              "destructive_command", "excessive_agency", "hallucination")


class ServiceGuardrailResult(ResponseModel):
    profile: Literal["guardrail.1"]
    confidence: float = Field(ge=0, le=1)
    category_confidence: float = Field(ge=0, le=1)
    assessed_at: Timestamp
    billing: BillingReceipt


class ServiceScoredGuardrail(ServiceGuardrailResult):
    status: Literal["scored"]
    category: Literal[*CATEGORIES, "none"]
    score: float = Field(ge=0, le=100)
    level: Literal["info", "low", "medium", "high", "critical"]


class ServiceUnscoredGuardrail(ServiceGuardrailResult):
    status: Literal["unscored"]
    category: Literal["unknown"]
    score: None
    level: None


class ServiceFailedGuardrail(ResponseModel):
    profile: Literal["guardrail.1"]
    status: Literal["error"]
    reason: Literal["authentication_failed", "provider_unavailable", "provider_rejected",
                    "invalid_response", "response_too_large", "connection_failed"]
    retryable: bool
    retry_after: float = Field(ge=30, le=3600)
    billing: BillingReceipt


class ServiceGuardrailAssessment(RootModel[Annotated[
        ServiceScoredGuardrail | ServiceUnscoredGuardrail | ServiceFailedGuardrail, Field(discriminator="status")]]):
    """Advisory assessments never contain a policy decision."""
