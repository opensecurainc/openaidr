"""Bounded receiver readiness shared by the service and its tenant client."""

from typing import Annotated, Literal

from pydantic import Field, model_validator

from .base import ResponseModel


CAPABILITIES = (
    "url_reputation", "package_vulnerabilities", "guardrail", "application_research",
    "assistant", "rule_generation", "overview_summaries", "session_summaries",
    "skill_assessment", "investigations",
)
State = Literal["configured", "provider_unconfigured", "runtime_unavailable"]
Name = Annotated[str, Field(pattern=r"^[a-z][a-z0-9_]{0,63}$")]


class Capabilities(ResponseModel):

    tenant_id: str = Field(pattern=r"^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$")
    build: str = Field(min_length=1, max_length=128)
    capabilities: dict[Name, State] = Field(min_length=len(CAPABILITIES), max_length=32)
    provider_access: Literal["not_checked"]
    investigation_worker: Literal["not_checked"]

    @model_validator(mode="after")
    def required_capabilities(self):
        if not set(CAPABILITIES) <= self.capabilities.keys():
            raise ValueError("Required capability status is missing")
        return self
