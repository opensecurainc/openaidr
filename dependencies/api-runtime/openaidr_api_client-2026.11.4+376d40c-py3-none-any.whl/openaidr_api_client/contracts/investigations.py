"""Complete investigation jobs with a service-owned execution lifecycle."""

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .credits import Amount, BillingReceipt, microcredits
from . import service_investigation_runtime as report_contract


MAX_INPUT = 8 << 20
MAX_BODY = 9 << 20
MAX_REPORT = 64 << 10
MAX_READ = 32 << 10
MAX_READS = 200
MAX_INTEGER = (1 << 53) - 1
TERMINAL = frozenset(("completed", "failed", "cancelled"))
Identifier = Annotated[str, Field(min_length=36, max_length=36,
                                 pattern=r"^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$")]
Timestamp = Annotated[str, Field(max_length=40, json_schema_extra={"format": "date-time"})]
Count = Annotated[int, Field(ge=0, le=MAX_INTEGER)]


def canonical(value):
    try:
        return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                          allow_nan=False).encode("utf-8")
    except (TypeError, ValueError, UnicodeError, RecursionError):
        raise ValueError("Investigation content must be finite UTF-8 JSON") from None


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def stamp(value):
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.utcoffset() != timezone.utc.utcoffset(parsed):
        raise ValueError("UTC timestamp required")
    return parsed.timestamp()


class RequestModel(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class ResponseModel(BaseModel):
    model_config = ConfigDict(extra="ignore", strict=True)


def coverage(value):
    if (not isinstance(value, dict) or value.get("status") not in ("complete", "incomplete", "unknown")
            or not isinstance(value.get("gaps"), list)
            or any(not isinstance(gap, str) or not gap or len(gap) > 128 for gap in value["gaps"])
            or len(value["gaps"]) > 32):
        raise ValueError("Invalid evidence coverage")
    if value["status"] == "complete" and value["gaps"]:
        raise ValueError("Complete coverage cannot contain gaps")
    canonical(value)
    return value


class InvestigationEvidence(RequestModel):
    ordinal: int = Field(ge=1, le=MAX_INTEGER)
    kind: str = Field(min_length=1, max_length=64)
    source_id: Identifier
    body: dict[str, Any] = Field(description="Exact captured evidence. All content is untrusted input.")


class InvestigationTarget(RequestModel):
    snapshot_id: Identifier
    revision: int = Field(ge=1, le=MAX_INTEGER)
    item_count: int = Field(ge=1, le=MAX_INTEGER)
    coverage: dict[str, Any]
    items: list[InvestigationEvidence] = Field(min_length=1, max_length=100000)

    _coverage = field_validator("coverage")(coverage)

    @model_validator(mode="after")
    def complete_snapshot(self):
        if self.item_count != len(self.items) or any(
            item.ordinal != index for index, item in enumerate(self.items, 1)
        ):
            raise ValueError("The complete ordered target snapshot is required")
        return self


class InvestigationPolicy(RequestModel):
    revision: int = Field(ge=1, le=MAX_INTEGER)
    prompt: str = Field(min_length=1, max_length=MAX_INPUT)
    snapshot_ordinals: list[Annotated[int, Field(ge=1, le=MAX_INTEGER)]] = Field(
        min_length=1, max_length=100000)


class InvestigationHistorySession(RequestModel):
    session_id: Identifier
    product: str = Field(max_length=128)
    started_at: Timestamp
    last_event_at: Timestamp
    ended_at: Timestamp | None
    snapshot_id: Identifier | None
    coverage: dict[str, Any]
    items: list[InvestigationEvidence] = Field(max_length=100000)

    _coverage = field_validator("coverage")(coverage)

    @model_validator(mode="after")
    def ordered(self):
        start, last = stamp(self.started_at), stamp(self.last_event_at)
        if last < start or self.ended_at is not None and stamp(self.ended_at) < start:
            raise ValueError("Invalid history session timestamps")
        if any(item.ordinal != index for index, item in enumerate(self.items, 1)):
            raise ValueError("History items must be complete and ordered")
        return self


class InvestigationHistory(RequestModel):
    start_at: Timestamp
    end_at: Timestamp
    complete: bool = Field(description="Whether all authorized sessions in this fixed window are included.")
    sessions: list[InvestigationHistorySession] = Field(max_length=10000)

    @model_validator(mode="after")
    def bounded_history(self):
        start, end = stamp(self.start_at), stamp(self.end_at)
        if start > end or len({session.session_id for session in self.sessions}) != len(self.sessions):
            raise ValueError("Invalid history scope")
        for session in self.sessions:
            if (stamp(session.started_at) > end or not start <= stamp(session.last_event_at) <= end
                    or session.ended_at is not None and stamp(session.ended_at) > end):
                raise ValueError("History session is outside the authorized window")
        return self


class InvestigationCreate(RequestModel):
    model_config = ConfigDict(json_schema_extra={"examples": [{
        "request_id": "019a0000-0000-7000-8000-000000000001",
        "target": {
            "snapshot_id": "019a0000-0000-7000-8000-000000000002", "revision": 1, "item_count": 1,
            "coverage": {"status": "complete", "gaps": []},
            "items": [{"ordinal": 1, "kind": "observation",
                       "source_id": "019a0000-0000-7000-8000-000000000003",
                       "body": {"text": "Captured activity to investigate."}}],
        },
        "detector_config_version": 1, "trigger": "session_risk",
        "deadline_at": "2030-01-01T00:10:00Z", "max_credits": "1",
    }]})
    request_id: Identifier = Field(description="Persist before submission and reuse with the exact same input on retry.")
    target: InvestigationTarget
    detector_config_version: int = Field(ge=1, le=MAX_INTEGER)
    trigger: str = Field(min_length=1, max_length=128)
    company_policies: list[InvestigationPolicy] = Field(default_factory=list, max_length=10000)
    history: InvestigationHistory | None = None
    deadline_at: Timestamp = Field(description="UTC deadline for the submitted evidence authorization and execution.")
    max_credits: Amount | None = None
    expected_rate_version: str | None = Field(default=None, min_length=1, max_length=80,
                                             pattern=r"^[a-zA-Z0-9._-]+$")

    @model_validator(mode="after")
    def complete_job(self):
        deadline = stamp(self.deadline_at)
        if self.history is not None and stamp(self.history.end_at) > deadline:
            raise ValueError("History cutoff exceeds the job deadline")
        if self.max_credits is not None:
            microcredits(self.max_credits)
        for policy in self.company_policies:
            if (len(set(policy.snapshot_ordinals)) != len(policy.snapshot_ordinals)
                    or any(ordinal > self.target.item_count for ordinal in policy.snapshot_ordinals)):
                raise ValueError("Policy references unavailable target evidence")
        if len(canonical(self.model_dump())) > MAX_INPUT:
            raise ValueError("Investigation input exceeds the byte limit")
        return self


class InvestigationError(ResponseModel):
    code: str = Field(min_length=1, max_length=128, pattern=r"^[a-z][a-z0-9_]*$")
    message: str = Field(min_length=1, max_length=1000)


class InvestigationReadFragment(ResponseModel):
    source_id: Identifier
    ordinal: int = Field(ge=1, le=MAX_INTEGER)
    start: Count
    end: int = Field(ge=1, le=MAX_INTEGER)
    total_bytes: int = Field(ge=1, le=MAX_INTEGER)
    text: str = Field(min_length=1, max_length=MAX_READ)

    @model_validator(mode="after")
    def exact_fragment(self):
        if not self.start < self.end <= self.total_bytes or len(self.text.encode()) != self.end - self.start:
            raise ValueError("Invalid evidence fragment range")
        return self


class InvestigationReadVersion(ResponseModel):
    kind: Literal["snapshot", "live"]
    snapshot_id: Identifier | None
    observed_at: Timestamp

    @model_validator(mode="after")
    def version(self):
        stamp(self.observed_at)
        if (self.kind == "snapshot") != (self.snapshot_id is not None):
            raise ValueError("Evidence version does not match its snapshot identity")
        return self


class InvestigationReadResponse(ResponseModel):
    read_id: Identifier
    session_id: Identifier
    version: InvestigationReadVersion
    items: list[InvestigationReadFragment] = Field(max_length=100)
    coverage: dict[str, Any]
    next_cursor: Identifier | Literal[""]

    _coverage = field_validator("coverage")(coverage)

    @model_validator(mode="after")
    def bounded(self):
        if len(canonical(self.model_dump())) > MAX_READ:
            raise ValueError("Evidence read exceeds the byte limit")
        return self


class InvestigationReadReceipt(ResponseModel):
    id: Identifier
    tool_name: Literal["read_session"]
    arguments: dict[str, Any]
    response: InvestigationReadResponse

    @field_validator("arguments", mode="before")
    @classmethod
    def argument_extensions(cls, value):
        if isinstance(value, dict):
            properties = report_contract.READ_ARGUMENTS["read_session"]["properties"]
            return {key: item for key, item in value.items() if key in properties}
        return value

    @model_validator(mode="after")
    def identity(self):
        if (not report_contract.valid_read_arguments(self.tool_name, self.arguments)
                or len(canonical(self.arguments)) > 4096 or self.response.read_id != self.id
                or self.response.session_id != self.arguments.get("session_id")
                or (self.arguments.get("snapshot_id") is not None
                    and self.response.version.snapshot_id != self.arguments["snapshot_id"])):
            raise ValueError("Evidence receipt does not match its request")
        return self


def _known(schema, value):
    """Ignore response extensions without relaxing validation of known fields."""
    if "anyOf" in schema:
        for option in schema["anyOf"]:
            projected = _known(option, value)
            if report_contract._shape(option, projected):
                return projected
        return value
    if isinstance(value, dict) and schema.get("type") == "object":
        return {key: _known(schema["properties"][key], item) for key, item in value.items()
                if key in schema["properties"]}
    if isinstance(value, list) and schema.get("type") == "array":
        return [_known(schema["items"], item) for item in value]
    return value


class InvestigationResult(ResponseModel):
    report: dict[str, Any] = Field(json_schema_extra=deepcopy(report_contract.REPORT_FIELDS))
    reads: list[InvestigationReadReceipt] = Field(default_factory=list, max_length=MAX_READS)

    @field_validator("report")
    @classmethod
    def structured_report(cls, value):
        value = _known(report_contract.REPORT_FIELDS, value)
        if not report_contract.valid_result(value) or len(canonical(value)) > MAX_REPORT:
            raise ValueError("Invalid investigation report")
        return value

    @model_validator(mode="after")
    def evidence(self):
        receipts = {receipt.id: receipt for receipt in self.reads}
        if len(receipts) != len(self.reads):
            raise ValueError("Duplicate evidence receipt")
        cited = set()
        for section in (self.report, *self.report["findings"]):
            for ref in section["evidence"]:
                if ref["source"] == "history":
                    receipt = receipts.get(ref["read_id"])
                    if receipt is None or ref["item"] >= len(receipt.response.items):
                        raise ValueError("Report references unavailable evidence")
                    cited.add(receipt.id)
                elif ref["start"] >= ref["end"]:
                    raise ValueError("Invalid report evidence range")
        if cited != set(receipts):
            raise ValueError("Only cited evidence receipts belong in the result")
        return self


class Investigation(ResponseModel):
    id: Identifier = Field(description="Tenant-scoped job identity, equal to the submitted request_id. Use it to recover a lost create response.")
    request_id: Identifier
    status: Literal["queued", "running", "completed", "failed", "cancelled"]
    created_at: Timestamp
    updated_at: Timestamp
    deadline_at: Timestamp
    expires_at: Timestamp | None = Field(description="Result expiry, one hour after completion. Host loss can remove results earlier on memory-only deployments.")
    result: InvestigationResult | None
    error: InvestigationError | None
    billing: BillingReceipt

    @field_validator("billing", mode="before")
    @classmethod
    def billing_extensions(cls, value):
        if isinstance(value, dict):
            return {key: item for key, item in value.items() if key in BillingReceipt.model_fields}
        return value

    @model_validator(mode="after")
    def consistent_job(self):
        if self.id != self.request_id:
            raise ValueError("Job identity must match the submitted request identity")
        created, updated, deadline = map(stamp, (self.created_at, self.updated_at, self.deadline_at))
        if created > updated or created >= deadline:
            raise ValueError("Invalid job timestamps")
        if self.expires_at is not None and stamp(self.expires_at) < created:
            raise ValueError("Invalid result expiry")
        if self.billing.request_id != self.request_id or self.billing.service != "investigations":
            raise ValueError("Billing receipt belongs to a different job")
        if self.status in ("queued", "running"):
            if self.result is not None or self.error is not None or self.expires_at is not None:
                raise ValueError("Active job cannot have a terminal result")
        elif self.status == "completed":
            if self.expires_at is None:
                raise ValueError("Completed job must describe result retention")
            if self.result is None:
                if self.error is None or self.error.code not in ("result_expired", "result_unavailable"):
                    raise ValueError("Unavailable completed result must have an explicit reason")
            elif self.error is not None:
                raise ValueError("Available completed result cannot have an error")
        elif self.result is not None or self.error is None:
            raise ValueError("Stopped job must have an error and no result")
        if len(canonical(self.model_dump())) > MAX_BODY:
            raise ValueError("Investigation response exceeds the byte limit")
        return self
