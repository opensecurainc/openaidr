"""Full pinned scans over redacted text with one customer credit receipt."""

import hashlib
import json
from pathlib import PurePosixPath
from typing import Annotated, Any, Literal

from pydantic import ConfigDict, Field, RootModel, field_validator, model_validator

from .base import Model, ResponseModel
from .credits import BillingReceipt
from .service_skill_bundles import ServiceSkillBundleRequest, SkillBundleFile
from .service_skills import REVISION

PROFILE = "skill-full-scan.1"
MAX_BODY = 12 << 20
MAX_RESPONSE = 8 << 20
MAX_SEEDS = 1 << 20
STATIC_ANALYZERS = (
    "artifact_integrity", "behavioral_ast", "behavioral_taint_tracking", "bundled_execution_surface",
    "mcp_least_privilege", "mcp_rug_pull", "static_yara", "structured_skill_roles",
    "static_patterns_agent_snooping", "static_patterns_anti_refusal", "static_patterns_data_exfiltration",
    "static_patterns_deserialization", "static_patterns_excessive_agency", "static_patterns_harmful_content",
    "static_patterns_memory_poisoning", "static_patterns_output_handling", "static_patterns_privilege_escalation",
    "static_patterns_prompt_injection", "static_patterns_rogue_agent", "static_patterns_ssrf",
    "static_patterns_supply_chain", "static_patterns_system_prompt_leakage", "static_patterns_tool_misuse",
)


class StaticSkillFinding(Model):
    source_analyzer: Literal[*STATIC_ANALYZERS]
    rule_id: str = Field(min_length=1, max_length=128)
    finding_id: str = Field(min_length=1, max_length=128)
    severity: Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]
    file: str = Field(min_length=1, max_length=1024)
    start_line: int = Field(ge=1, le=10000000)
    end_line: int | None = Field(default=None, ge=1, le=10000000)
    confidence: float = Field(default=.5, ge=0, le=1)
    message: str = Field(max_length=4096)
    matched_text: str | None = Field(default=None, max_length=16384)
    context: str | None = Field(default=None, max_length=16384)
    explanation: str | None = Field(default=None, max_length=4096)
    remediation: str | None = Field(default=None, max_length=4096)

    @field_validator("file")
    @classmethod
    def safe_file(cls, value):
        return SkillBundleFile.safe_path(value)

    @model_validator(mode="after")
    def line_range(self):
        if self.end_line is not None and self.end_line < self.start_line:
            raise ValueError("Invalid finding range")
        return self


class ServiceSkillScanRequest(ServiceSkillBundleRequest):
    model_config = ConfigDict(json_schema_extra={"examples": [{
        "profile": PROFILE, "revision": REVISION, "bundle_sha256": "a" * 64,
        "files": [{"path": "SKILL.md", "content": "# Example\nUse the documented command.\n"}],
        "static_findings": [], "timeout_ms": 600000,
    }]})
    profile: Literal[PROFILE]
    timeout_ms: int = Field(default=600000, ge=1, le=600000)
    static_findings: list[StaticSkillFinding] = Field(default_factory=list, max_length=500)

    @model_validator(mode="after")
    def seed_scope(self):
        if any("\0" in item.content for item in self.files):
            raise ValueError("Binary content is not supported")
        paths = {item.path for item in self.files}
        if any(str(parent) in paths for path in paths for parent in PurePosixPath(path).parents if str(parent) != "."):
            raise ValueError("Conflicting file paths")
        if any(item.file not in paths for item in self.static_findings):
            raise ValueError("Local findings must name submitted text paths")
        lines = {item.path: max(1, len(item.content.splitlines())) for item in self.files}
        if any((item.end_line or item.start_line) > lines[item.file] for item in self.static_findings):
            raise ValueError("Local finding range exceeds submitted text")
        if len({item.finding_id for item in self.static_findings}) != len(self.static_findings):
            raise ValueError("Duplicate local finding ID")
        if len(json.dumps([item.model_dump() for item in self.static_findings], ensure_ascii=False, allow_nan=False).encode()) > MAX_SEEDS:
            raise ValueError("Local finding seed exceeds byte limit")
        return self


def request_hash(task):
    public = ServiceSkillScanRequest.model_validate(task).model_dump()
    return hashlib.sha256(json.dumps(public, sort_keys=True, allow_nan=False).encode()).hexdigest()


class CompletedSkillScan(ResponseModel):
    profile: Literal[PROFILE]
    status: Literal["completed"]
    request_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    result: dict[str, Any]
    billing: BillingReceipt


class FailedSkillScan(ResponseModel):
    profile: Literal[PROFILE]
    status: Literal["error"]
    request_hash: str = Field(pattern=r"^[0-9a-f]{64}$")
    code: Literal["timeout", "provider_unavailable", "invalid_response", "runtime_unavailable", "response_limit", "scanner_failed"]
    result: dict[str, Any]
    billing: BillingReceipt


class ServiceSkillScanResponse(RootModel[Annotated[CompletedSkillScan | FailedSkillScan, Field(discriminator="status")]]):
    pass


def validate_response(task, value):
    parsed = ServiceSkillScanResponse.model_validate(value).root
    if parsed.request_hash != request_hash(task):
        raise ValueError("Unbound full skill scan")
    return parsed
