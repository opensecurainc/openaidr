"""Submit, inspect, and cancel complete jobs without driving service execution."""

import asyncio
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import math
from time import monotonic, sleep

import httpx
from pydantic import TypeAdapter

from .client import ServiceErrorCode, Unavailable
from .latency import measured
from .contracts import investigations as wire


PREFIX = "/v1/investigations"
_identifier = TypeAdapter(wire.Identifier)


def _response(value, *, request_id=None, ident=None):
    try:
        job = wire.Investigation.model_validate(value)
        if request_id is not None and job.request_id != request_id or ident is not None and job.id != ident:
            raise ValueError("Investigation identity differs")
        return job
    except ValueError:
        raise Unavailable("Invalid investigation response") from None


@measured("investigation_create")
async def submit(client, request, *, timeout=10):
    request = wire.InvestigationCreate.model_validate(request)
    value = await client.request(PREFIX, request.model_dump(exclude_unset=True), wire.MAX_BODY, timeout,
                                 accepted_status=(200, 202), request_id=request.request_id)
    return _response(value, request_id=request.request_id)


@measured("investigation_create")
def submit_sync(client, request, *, timeout=10):
    request = wire.InvestigationCreate.model_validate(request)
    value = client.request(PREFIX, request.model_dump(exclude_unset=True), wire.MAX_BODY, timeout,
                           accepted_status=(200, 202), request_id=request.request_id)
    return _response(value, request_id=request.request_id)


@measured("investigation_status")
async def get(client, ident, *, timeout=10):
    ident = _identifier.validate_python(ident)
    value = await client.request(PREFIX + "/" + ident, None, wire.MAX_BODY, timeout, method="GET")
    return _response(value, ident=ident)


@measured("investigation_status")
def get_sync(client, ident, *, timeout=10):
    ident = _identifier.validate_python(ident)
    value = client.request(PREFIX + "/" + ident, None, wire.MAX_BODY, timeout, method="GET")
    return _response(value, ident=ident)


@measured("investigation_cancel")
async def cancel(client, ident, *, timeout=10):
    ident = _identifier.validate_python(ident)
    value = await client.request(PREFIX + "/" + ident + "/cancel", {}, wire.MAX_BODY, timeout,
                                 accepted_status=(200, 202))
    return _response(value, ident=ident)


@measured("investigation_cancel")
def cancel_sync(client, ident, *, timeout=10):
    ident = _identifier.validate_python(ident)
    value = client.request(PREFIX + "/" + ident + "/cancel", {}, wire.MAX_BODY, timeout,
                           accepted_status=(200, 202))
    return _response(value, ident=ident)


class InvestigationWaitTimeout(TimeoutError):
    """The local wait expired; this does not cancel or fail the investigation."""

    def __init__(self, ident, last_status):
        super().__init__("Investigation polling deadline exceeded")
        self.investigation_id = ident
        self.last_status = last_status


class _Polling:
    def __init__(self, ident, timeout, request_timeout, poll_interval, max_interval):
        self.ident = _identifier.validate_python(ident)
        for value in (timeout, request_timeout, poll_interval, max_interval):
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
                raise ValueError("Polling time limits must be finite positive numbers")
        if poll_interval > max_interval:
            raise ValueError("Polling interval exceeds maximum interval")
        self.deadline = monotonic() + timeout
        self.request_timeout, self.interval, self.maximum = request_timeout, poll_interval, max_interval
        self.last_status, self.errors = None, 0

    def remaining(self):
        remaining = self.deadline - monotonic()
        if remaining <= 0:
            raise InvestigationWaitTimeout(self.ident, self.last_status) from None
        return remaining

    def delay(self, error=None):
        if error is None:
            self.errors = 0
            return min(self.interval, self.remaining())
        if isinstance(error, Unavailable) and (
                error.error_code == ServiceErrorCode.JOB_OWNER_UNAVAILABLE
                or error.status_code not in (408, 429, 500, 502, 503, 504)):
            raise error
        self.errors = min(self.errors + 1, 20)
        delay = min(self.maximum, self.interval * 2 ** (self.errors - 1))
        if isinstance(error, Unavailable) and error.retry_after:
            try:
                raw = error.retry_after.strip()
                requested = float(int(raw)) if raw.isascii() and raw.isdigit() else (
                    parsedate_to_datetime(raw) - datetime.now(timezone.utc)).total_seconds()
                if math.isfinite(requested):
                    delay = max(delay, requested)
            except (ValueError, TypeError, OverflowError):
                pass
        # A long Retry-After exhausts the local wait rather than being ignored.
        return min(delay, self.remaining())


async def wait(client, ident, *, timeout=60, request_timeout=10, poll_interval=1, max_interval=10):
    """Poll the same ID until terminal. Never submit, cancel, or restart a job.

    Read-only transient errors retry within timeout. Owner unavailability and
    permanent errors raise Unavailable immediately. A local timeout does not
    establish job failure; callers can resume waiting with the same ID.
    """
    polling = _Polling(ident, timeout, request_timeout, poll_interval, max_interval)
    while True:
        limit = min(request_timeout, polling.remaining())
        try:
            async with asyncio.timeout(limit):
                job = await get(client, polling.ident, timeout=limit)
        except (Unavailable, httpx.TransportError, TimeoutError) as error:
            delay = polling.delay(error)
        else:
            polling.last_status = job.status
            if job.status in wire.TERMINAL:
                return job
            delay = polling.delay()
        await asyncio.sleep(delay)


def wait_sync(client, ident, *, timeout=60, request_timeout=10, poll_interval=1, max_interval=10):
    """Synchronous counterpart of wait; never creates a replacement job."""
    polling = _Polling(ident, timeout, request_timeout, poll_interval, max_interval)
    while True:
        limit = min(request_timeout, polling.remaining())
        try:
            job = get_sync(client, polling.ident, timeout=limit)
        except (Unavailable, httpx.TransportError, TimeoutError) as error:
            delay = polling.delay(error)
        else:
            polling.last_status = job.status
            if job.status in wire.TERMINAL:
                return job
            delay = polling.delay()
        sleep(delay)
