"""Explicit feedback delivery without model execution or automatic retries."""

from pydantic import TypeAdapter

from .client import IntelligenceClient, Unavailable
from .latency import measured
from .contracts.capabilities import Capabilities
from .contracts.feedback import Feedback, FeedbackReceipt, FeedbackDeletion, UUID, MAX_BODY, canonical, digest, stamp


class FeedbackClient(IntelligenceClient):
    @measured("capabilities")
    async def supported(self):
        try:
            value = await self.request("/v1/capabilities", None, 16384, 10, method="GET")
        except Unavailable as error:
            if error.status_code == 404:
                return False
            raise
        try:
            result = Capabilities.model_validate(value)
            if result.tenant_id != self.tenant_id:
                raise ValueError("Feedback capability tenant differs")
        except ValueError:
            raise Unavailable("Invalid feedback capability response") from None
        return result.capabilities.get("feedback") == "configured"

    @measured("other")
    async def submit(self, payload):
        payload = Feedback.model_validate(payload).model_dump()
        if len(canonical(payload)) > MAX_BODY:
            raise ValueError("Feedback request exceeds limit")
        value = await self.request("/v1/feedback", payload, 4096, 15)
        try:
            receipt = FeedbackReceipt.model_validate(value)
            if (receipt.tenant_id != self.tenant_id or receipt.feedback_id != payload["feedback_id"]
                    or receipt.revision != payload["revision"] or receipt.request_sha256 != digest(payload)
                    or stamp(receipt.expires_at) != stamp(payload["expires_at"])
                    or stamp(receipt.received_at) >= stamp(receipt.expires_at)):
                raise ValueError("Feedback receipt differs")
        except ValueError:
            raise Unavailable("Invalid feedback receipt") from None
        return receipt.model_dump()

    @measured("other")
    async def delete(self, feedback_id):
        ident = TypeAdapter(UUID).validate_python(feedback_id)
        value = await self.request("/v1/feedback/" + ident + "/delete", {}, 4096, 15)
        try:
            receipt = FeedbackDeletion.model_validate(value)
            if receipt.tenant_id != self.tenant_id or receipt.feedback_id != ident:
                raise ValueError("Feedback deletion differs")
            stamp(receipt.deleted_at)
        except ValueError:
            raise Unavailable("Invalid feedback deletion receipt") from None
        return receipt.model_dump()
