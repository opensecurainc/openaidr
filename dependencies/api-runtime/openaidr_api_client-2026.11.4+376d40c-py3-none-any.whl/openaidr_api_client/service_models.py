"""Compatibility imports for feature-owned customer service contracts."""

from .contracts.service_generation import (
    ServiceGenerationRequest as ServiceGenerationRequest,
    ServiceGenerationError as ServiceGenerationError,
)

from .contracts.service_assistant import (
    ServiceCurrentPage as ServiceCurrentPage,
    ServiceChatMessage as ServiceChatMessage,
    ServiceAssistantRequest as ServiceAssistantRequest,
    ServiceAnswer as ServiceAnswer,
    ServiceAssistantCompleted as ServiceAssistantCompleted,
    ServiceAssistantResponse as ServiceAssistantResponse,
)

from .contracts.service_summaries import (
    ServiceSummarySource as ServiceSummarySource,
    ServiceOverviewRequest as ServiceOverviewRequest,
    ServiceSessionSummaryRequest as ServiceSessionSummaryRequest,
    ServiceSummaryRequest as ServiceSummaryRequest,
    ServiceSummaryItem as ServiceSummaryItem,
    ServiceOverviewResult as ServiceOverviewResult,
    ServiceSessionSummaryResult as ServiceSessionSummaryResult,
    ServiceSummaryCompleted as ServiceSummaryCompleted,
    ServiceSummaryResponse as ServiceSummaryResponse,
)

from .contracts.service_rules import (
    ServiceRuleRequest as ServiceRuleRequest,
    ServiceRuleDraft as ServiceRuleDraft,
    ServiceDraftResult as ServiceDraftResult,
    ServiceClarification as ServiceClarification,
    ServiceRuleCompleted as ServiceRuleCompleted,
    ServiceRuleResponse as ServiceRuleResponse,
)

from .contracts.service_applications import (
    APPLICATION_RESULT_SCHEMA as APPLICATION_RESULT_SCHEMA,
    ServiceCompletedApplication as ServiceCompletedApplication,
    ServiceFailedApplication as ServiceFailedApplication,
    ServiceApplicationAssessment as ServiceApplicationAssessment,
)
