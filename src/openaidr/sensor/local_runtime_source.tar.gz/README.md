<div align="center">

# <img src="apps/dashboard/public/icon.svg" alt="" width="40" height="40" align="top"> OpenAIDR by [OpenSecura](https://opensecura.ai/)

**Visibility and guardrails for your AI tools.**

[![License: Apache 2.0](https://img.shields.io/badge/License-Apache_2.0-193b6c)](LICENSE) [![Self-hosted](https://img.shields.io/badge/Deployment-Self--hosted-0b7a87)](#quick-start)

[Quick start](#quick-start) · [Releases](https://github.com/opensecurainc/openaidr/releases) · [Documentation](docs/guide.md) · [Data handling](docs/data-handling.md) · [Open source plan](docs/open-source-plan.md) · [Contributing](CONTRIBUTING.md)

</div>

OpenAIDR is Agentic AI Detection and Response. The sensor and desktop app
collect coding agent activity from endpoints, the dashboard you host shows
which AI tools and agents are in use and what they did, and guardrails apply
decisions at supported agent hooks before actions run. Model-backed detection
and guardrail decisions come from the OpenSecura Intelligence service.

https://github.com/user-attachments/assets/9c1009a7-d455-4be3-adac-4dd8bf18932c

*15-second product tour: desktop app and dashboard, a tool call flagged by the
guardrail, live activity, and AI agent costs. All user and usage data is synthetic.*

## News

- **2026-10-22:** [OpenAIDR launches](https://github.com/opensecurainc/openaidr#quick-start) with AI visibility and real-time guardrails for enterprises.

## What you can do

- **See which AI tools are in use.** Review known applications, observed users,
  and approval status across enrolled devices.
- **Inspect AI dependencies.** Inventory MCP servers and plugins, and review
  known vulnerability matches.
- **Understand agent usage.** Review tokens and estimated costs by user and agent
  in the dashboard, plus local Codex and Claude Code usage in the desktop app.
- **Review configuration risks.** Check supported AI tool settings for approval
  bypasses and exposed credentials.
- **Set your own guardrails.** Define command, text, path, and host rules. Start
  in Shadow mode to review matches, then enable Enforce at supported agent hooks.
- **Detect and respond.** Review live activity and session evidence, detection
  queues, user risk, detection rules, and investigation reports.
- **Add model-backed decisions.** With the OpenSecura Intelligence service
  connected, guardrails assess prompts, tool calls, and results inline, URLs are
  checked for reputation, and the Overview and session summaries are written for
  you.

## Open source plan

This repository is the complete OpenAIDR client: the sensor and agent hooks,
the desktop app, the dashboard, the local server, and the vendored SDK that
calls the OpenSecura API. Model-backed detection and guardrail decisions run
behind that API. Without a configured Intelligence service, inventory, manual
guardrails, costs, and administration work on their own, and the model-backed
pages report the service as not configured.

The [open source plan](docs/open-source-plan.md) describes what stays public,
what runs behind the API, and how privacy and availability are handled. New local
workspaces automatically enroll for a $2 monthly allowance when the hosted free
service is enabled. Usage is charged at actual provider cost. The desktop shows
credit and connection status; local storage and rules continue to work when the
API is unavailable. Existing paid credentials remain supported.

## Quick start

Run OpenAIDR locally for development and evaluation.

### Build the current client

Install **Docker with Compose** and **Python 3.11+**, then build the current source:

```sh
git clone https://github.com/opensecurainc/openaidr.git
cd openaidr
python3 scripts/local_stack.py configure
docker compose up --build -d
```

Open <http://localhost:8080>. Sign in as `admin@localhost` with the generated
`OPENAIDR_ADMIN_PASSWORD` in `.env`. Keep this file: it also holds the installation's
free-enrollment identity and secret. Re-running configuration preserves them.
Existing workspaces keep their identity and explicit API connection; configuration
does not replace them with a new free account. Follow the [desktop build instructions](docs/guide.md#build-the-app)
for macOS Apple Silicon, Windows x64, or Linux x64.

### Install a complete macOS release

With Docker Desktop and Python 3.11+ installed, run `./setup.sh` from the
checkout. Setup accepts only public releases with a verified
full-client manifest, matching backend images, and a macOS ARM64 installer.
It refuses older reduced releases. Until a complete full-client release is
published, use the source build above. Allow Finder automation or opening the
unsigned app if macOS asks.

Connect your device:

1. In the dashboard, open **Administration > App Enrollment**.
2. Create an enrollment link and paste it into the desktop app's connection dialog.
3. Confirm the app shows **Connected**, then use your supported AI tools as usual.

Inventory, manual guardrails, costs, and administration need no hosted service
or model key. Detection, investigations, model-backed guardrail decisions, URL
reputation, and the Overview summary use the OpenSecura Intelligence service:
set `OPENAIDR_INTELLIGENCE_ORIGIN` and `OPENAIDR_INTELLIGENCE_API_KEY` in
`.env` and restart Compose, then check the connection under
**Administration > Settings** in the **Intelligence service** card. Your AI
tools keep their own authentication requirements.

### Windows, Linux, or source builds

Use [Docker Compose setup](docs/guide.md#start-the-local-server) to run the server,
then follow the [desktop build instructions](docs/guide.md#build-the-app).
Desktop builds support macOS Apple Silicon, Windows x64, and Linux x64.
Build from a `git clone`. A downloaded archive has no Git history, so every
build step first needs `OPENAIDR_BUILD_COMMIT` (the full source commit SHA) and
`OPENAIDR_COMMIT_TIMESTAMP` (that commit's committer time as a Unix epoch) in
the environment; the scripts stop with that message otherwise.

For configuration, policy behavior, and testing, see the [full guide](docs/guide.md).

---

**Want OpenSecura to do the heavy lifting?** [Request a demo](https://forms.gle/FxMfNgBoM9NHkUmQA).
