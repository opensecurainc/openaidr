// Prepare generated assets before `next dev` and `next build`.
// The OpenSecura mark and palette are committed in this repository
// (public/icon.svg, public/icon-dark.svg, src/app/brand.css); the private brand
// submodule is not part of the public tree. Coding agent icons come from the
// shared set under packages/ui/agent-icons, and the Geist font license must
// accompany the font files that next/font bundles from the geist package.
import { copyFile, mkdir } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { syncAgentIcons } from "../../../scripts/sync-agent-icons.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
syncAgentIcons(path.join(root, "public/agent-icons"));
await mkdir(path.join(root, "public/fonts"), { recursive: true });
await copyFile(
  path.join(root, "node_modules/geist/LICENSE.txt"),
  path.join(root, "public/fonts/Geist-OFL.txt"),
);
