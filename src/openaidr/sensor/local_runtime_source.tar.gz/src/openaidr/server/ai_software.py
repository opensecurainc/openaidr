"""Known AI software, matched conservatively against installed-software records.

A record is AI software only when its identifier starts with a listed vendor
prefix or its name equals a listed product name (case-insensitive). Nothing is
inferred from descriptions, publishers, or partial names, so an unlisted AI
product is reported as an ordinary application rather than guessed at.
"""

# Bundle or package identifier prefixes owned by AI vendors or products.
IDENTIFIER_PREFIXES = (
    "com.anthropic.",  # Claude, Claude Code
    "com.openai.",  # ChatGPT, Codex
    "com.electron.ollama",  # Ollama for macOS
    "com.todesktop.230313mzl4w4u92",  # Cursor
    "com.exafunction.windsurf",  # Windsurf
    "ai.elementlabs.lmstudio",  # LM Studio
    "ai.perplexity.",  # Perplexity
)

# Exact product names, compared case-insensitively. Covers package managers and
# Windows registrations whose identifiers do not carry a vendor prefix.
NAMES = (
    "chatgpt",
    "claude",
    "claude code",
    "codex",
    "openai.codex",
    "cursor",
    "github copilot",
    "gpt4all",
    "lm studio",
    "ollama",
    "perplexity",
    "windsurf",
)

# Supporting components can be hidden without hiding the application itself.
# Match exact identifiers or names; a name containing "helper" is not evidence.
HELPER_IDENTIFIERS = ("com.anthropic.claude-code-url-handler",)
HELPER_NAMES = ("claude code url handler",)

# General-purpose products remain outside AI review even when they bundle
# optional AI features. Match installation identifiers, never publisher prefixes.
GENERAL_PURPOSE_IDENTIFIERS = frozenset({
    "com.google.chrome", "google chrome",
    "com.microsoft.edgemac", "microsoft edge",
    "com.apple.safari", "com.microsoft.outlook",
    "microsoft.outlookforwindows_8wekyb3d8bbwe",
    "microsoft.paint_8wekyb3d8bbwe", "microsoft.mspaint_8wekyb3d8bbwe",
})
