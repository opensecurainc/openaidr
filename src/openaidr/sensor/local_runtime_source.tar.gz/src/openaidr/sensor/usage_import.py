"""One-time, local-only usage import from retained coding-agent transcripts."""

from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import re

from openaidr.core.agent_usage import text, token, usage as measure
from openaidr.core.hook_estimates import price
from openaidr.core.reasoning import reasoning_effort
from . import hooks, usage


LINE_LIMIT = 8 << 20
DOCUMENT_LIMIT = 32 << 20
BATCH_SIZE = 100
# Standard text input, cached input, output USD per million tokens.
# https://ai.google.dev/gemini-api/docs/pricing (2026-10-28).
GEMINI_RATES = {
    "gemini-2.5-pro": ("1.25", "0.125", "10"),
    "gemini-2.5-flash": ("0.3", "0.03", "2.5"),
    "gemini-2.5-flash-lite": ("0.1", "0.01", "0.4"),
    "gemini-3-flash-preview": ("0.5", "0.05", "3"),
    "gemini-3.1-pro-preview": ("2", "0.2", "12"),
    "gemini-3.1-pro-preview-customtools": ("2", "0.2", "12"),
    "gemini-3.1-flash-lite": ("0.25", "0.025", "1.5"),
    "gemini-3.5-flash-lite": ("0.3", "0.03", "2.5"),
    "gemini-4-argon": ("2", "0.1", "10"),
}


def timestamp(value):
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return result if result.tzinfo is not None else None
    except (AttributeError, ValueError, TypeError):
        return None


def event(application, ident, when, attrs, effort):
    measured = measure(attrs, application + ".api_request", when=when)
    if measured is None or not measured["tokens"]:
        return None
    key = hashlib.sha256(json.dumps([application, ident], sort_keys=True).encode()).hexdigest()
    return dict(key="history:" + key, time=when, name=application + ".api_request",
                model=text(attrs, "model") or "Unattributed", reasoning_effort=effort or "unknown",
                usage=measured)


def claude(record):
    message = record.get("message")
    if record.get("type") != "assistant" or not isinstance(message, dict):
        return None
    counts = message.get("usage")
    when = timestamp(record.get("timestamp"))
    ident = text(message, "id") or text(record, "requestId")
    if not isinstance(counts, dict) or not when or not ident:
        return None
    attrs = dict(model=text(message, "model"), input_tokens=counts.get("input_tokens"),
                 output_tokens=counts.get("output_tokens"),
                 cache_read_tokens=counts.get("cache_read_input_tokens", 0),
                 cache_creation_tokens=counts.get("cache_creation_input_tokens", 0))
    result = event("claude_code", ident, when, attrs, reasoning_effort(record))
    if result is not None:
        result["usage"]["cost"] = claude_cost(attrs, counts)
    return result


def claude_cost(attrs, counts):
    """Apply the bundled base prices and recorded cache durations/modifiers."""
    model = re.sub(r"-\d{8}$", "", attrs["model"].lower().replace(".", "-"))
    incoming, outgoing, cached, written = (
        token(attrs, key) for key in ("input_tokens", "output_tokens", "cache_read_tokens", "cache_creation_tokens")
    )
    if None in (incoming, outgoing, cached, written):
        return None
    cache = counts.get("cache_creation") or {}
    if not isinstance(cache, dict):
        return None
    hour = token(cache, "ephemeral_1h_input_tokens", optional=True)
    short = token(cache, "ephemeral_5m_input_tokens", optional=True)
    if hour is None or short is None or hour + short > written:
        return None
    # https://platform.claude.com/docs/en/about-claude/pricing (2026-10-27).
    hit_rate = Decimal("0.05") if model in {"claude-opus-5-5", "claude-sonnet-5-5"} else Decimal("0.1")
    cost = price(model, incoming + cached * hit_rate + (written - hour) * Decimal("1.25") + hour * 2, outgoing)
    if cost is None or counts.get("service_tier") not in (None, "standard"):
        return None
    speed = counts.get("speed", "standard")
    if speed == "fast" and model in {"claude-opus-5-5", "claude-opus-5", "claude-opus-4-8"}:
        cost *= 2
    elif speed != "standard":
        return None
    geo = counts.get("inference_geo", "global")
    if geo == "us":
        cost *= Decimal("1.1")
    elif geo != "global":
        return None
    return cost


def codex_counts(value):
    if not isinstance(value, dict):
        return None
    counts = {target: token(value, source, optional=optional) for target, source, optional in (
        ("input_tokens", "input_tokens", False), ("output_tokens", "output_tokens", False),
        ("cached_token_count", "cached_input_tokens", True), ("cache_write_token_count", "cache_write_input_tokens", True),
    )}
    return counts if all(count is not None for count in counts.values()) else None


def codex(record, state):
    payload = record.get("payload")
    if not isinstance(payload, dict):
        return None
    if record.get("type") == "session_meta":
        state["session"] = text(payload, "id")
        state["forked_at"] = timestamp(payload.get("timestamp")) if payload.get("forked_from_id") else None
        return None
    if record.get("type") == "turn_context":
        state["model"] = text(payload, "model")
        state["effort"] = reasoning_effort(payload)
        state["tier"] = text(payload, "service_tier")
        state["turn"] = text(payload, "turn_id")
        return None
    if record.get("type") != "event_msg" or payload.get("type") != "token_count":
        return None
    info = payload.get("info")
    when = timestamp(record.get("timestamp"))
    if not isinstance(info, dict) or not when:
        return None
    total = codex_counts(info.get("total_token_usage"))
    if total is None:
        return None
    previous, state["previous"] = state.get("previous"), total
    if previous is not None:
        counts = {key: value - previous[key] for key, value in total.items()}
        if any(value < 0 for value in counts.values()):
            return None
    else:
        counts = codex_counts(info.get("last_token_usage")) or total
        if any(counts[key] > value for key, value in total.items()):
            return None
    # Copied parent history in a fork is already accounted for by its source.
    if state.get("forked_at") and when < state["forked_at"]:
        return None
    ident = state.get("turn") or state.get("session")
    if not ident:
        return None
    attrs = dict(counts, model=state.get("model", ""), service_tier=state.get("tier", ""))
    return event("codex", [ident, record["timestamp"], total], when, attrs, state.get("effort"))


def gemini(record):
    counts = record.get("tokens")
    when = timestamp(record.get("timestamp"))
    ident = text(record, "id")
    if record.get("type") != "gemini" or not isinstance(counts, dict) or not when or not ident:
        return None
    incoming, outgoing, cached, thoughts = (
        token(counts, key, optional=key in {"cached", "thoughts"}) for key in ("input", "output", "cached", "thoughts")
    )
    if None in (incoming, outgoing, cached, thoughts) or cached > incoming:
        return None
    model = text(record, "model")
    result = event("gemini", ident, when, dict(model=model, input_tokens=incoming - cached,
                   cache_read_tokens=cached, output_tokens=outgoing + thoughts), None)
    rates = GEMINI_RATES.get(model)
    if result is not None and rates is not None:
        rates = list(map(Decimal, rates))
        if model in {"gemini-2.5-pro", "gemini-3.1-pro-preview", "gemini-3.1-pro-preview-customtools"} and incoming > 200_000:
            rates = [rates[0] * 2, rates[1] * 2, rates[2] * Decimal("1.5")]
        if model == "gemini-4-argon" and when >= datetime(2026, 12, 1, tzinfo=timezone.utc):
            rates = [rate * 2 for rate in rates]
        result["usage"]["cost"] = sum(n * r for n, r in zip((incoming - cached, cached, outgoing + thoughts), rates)) / 1_000_000
    return result


def records(path, stop, paused):
    with path.open("rb") as source:
        if path.suffix == ".json":
            raw = source.read(DOCUMENT_LIMIT + 1)
            if len(raw) > DOCUMENT_LIMIT:
                return
            try:
                doc = json.loads(raw)
            except (ValueError, UnicodeError, RecursionError):
                return
            messages = doc.get("messages") if isinstance(doc, dict) else None
            if isinstance(messages, list):
                for record in messages:
                    if stop.is_set() or paused():
                        raise InterruptedError
                    if isinstance(record, dict):
                        yield record
            return
        while line := source.readline(LINE_LIMIT + 1):
            if stop.is_set() or paused():
                raise InterruptedError
            if len(line) > LINE_LIMIT:
                while line and not line.endswith(b"\n"):
                    if stop.is_set() or paused():
                        raise InterruptedError
                    line = source.readline(LINE_LIMIT + 1)
                continue
            try:
                record = json.loads(line)
            except (ValueError, UnicodeError, RecursionError):
                continue
            if isinstance(record, dict):
                yield record


def files(config, application, since):
    agent = "codex" if application == "codex" else "claude"
    if application == "gemini":
        home = Path(os.environ.get("GEMINI_CLI_HOME") or Path.home()) / ".gemini"
        names = ("tmp",)
    else:
        home = hooks.settings_path(agent, config).parent
        names = ("sessions", "archived_sessions") if agent == "codex" else ("projects",)
    found = {}

    def failed(error):
        raise error

    for name in names:
        root = home / name
        if not root.exists():
            continue
        for directory, _, names_in_directory in os.walk(root, onerror=failed):
            if application == "gemini" and "chats" not in Path(directory).relative_to(root).parts:
                continue
            for name in names_in_directory:
                if name.endswith((".json", ".jsonl") if application == "gemini" else ".jsonl"):
                    path = (Path(directory) / name).resolve()
                    try:
                        modified = path.stat().st_mtime
                    except FileNotFoundError:
                        continue
                    if modified >= since:
                        found[path] = modified
    return sorted(found, key=found.get, reverse=True)


def store(queue, application, events):
    if not events:
        return
    with queue.lock, queue.db:
        cutoff = queue.db.execute("SELECT cutoff FROM usage_imports WHERE scope=? AND application=?",
                                  (queue.usage_scope, application)).fetchone()[0]
        for item in events:
            if item["time"].timestamp() >= cutoff:
                continue
            previous = queue.db.execute("SELECT tokens FROM usage_calls WHERE scope=? AND event_key=?",
                                        (queue.usage_scope, item["key"])).fetchone()
            # Agents can write several blocks with the same message ID. Keep
            # final usage, including when a scan is interrupted and restarted.
            if previous and previous[0] < item["usage"]["tokens"]:
                queue.db.execute("DELETE FROM usage_calls WHERE scope=? AND event_key=?",
                                 (queue.usage_scope, item["key"]))
            usage.record_calls(queue.db, queue.usage_scope, [item])
        usage.prune(queue.db)


def run_once(config, queue, stop, paused=lambda: False):
    if not (config.get("telemetry") or {}).get("enabled", True) or stop.is_set() or paused():
        return False
    with queue.lock, queue.db:
        first = queue.db.execute("SELECT scope,started_at FROM usage_history ORDER BY rowid LIMIT 1").fetchone()
        if not first:
            return True
        for application in ("codex", "claude_code", "gemini"):
            earliest = queue.db.execute("""SELECT min(u.happened_at) FROM usage_calls u JOIN usage_apps a
                USING(scope,event_key) WHERE a.application=? AND u.event_key NOT LIKE 'history:%'""",
                (application,)).fetchone()[0]
            # Earlier versions did not collect Gemini usage. Import its recent
            # JSON history on upgrade as well as on a new installation.
            start = usage.datetime.now(timezone.utc).timestamp() if application == "gemini" else first["started_at"]
            cutoff = min(start, earliest) if earliest is not None else start
            # Older sensors treat every pending (0) non-Codex import as Claude.
            # State 2 keeps unfinished Gemini imports invisible on downgrade.
            queue.db.execute("INSERT OR IGNORE INTO usage_imports VALUES (?,?,?,?)",
                             (queue.usage_scope, application, cutoff, 2 if application == "gemini" else 0))
        pending = queue.db.execute("""SELECT application,cutoff FROM usage_imports WHERE scope=?
            AND completed IN (0,2) AND application IN ('codex','claude_code','gemini')""",
                                   (queue.usage_scope,)).fetchall()
    since = usage.local_start(usage.datetime.now(timezone.utc), 30).timestamp()
    finished = True
    for application, cutoff in pending:
        batch = []
        complete = True
        try:
            paths = files(config, application, since)
        except OSError:
            finished = False
            continue
        for path in paths:
            state = {}
            try:
                for record in records(path, stop, paused):
                    item = codex(record, state) if application == "codex" else gemini(record) if application == "gemini" else claude(record)
                    if item and since <= item["time"].timestamp() < cutoff:
                        batch.append(item)
                    if len(batch) >= BATCH_SIZE:
                        store(queue, application, batch)
                        batch.clear()
            except FileNotFoundError:
                continue
            except InterruptedError:
                return False
            except OSError:
                complete = False
        if stop.is_set() or paused():
            return False
        store(queue, application, batch)
        if complete:
            with queue.lock, queue.db:
                queue.db.execute("UPDATE usage_imports SET completed=1 WHERE scope=? AND application=?",
                                 (queue.usage_scope, application))
                usage.prune(queue.db)
        finished = finished and complete
    return finished


def run(config, queue, stop, paused=lambda: False):
    while not stop.is_set():
        try:
            if run_once(config, queue, stop, paused):
                return
        except Exception:
            # History is best effort and must never stop live collection. A
            # retry reuses stable record keys and the original import cutoff.
            pass
        stop.wait(30)
